<!doctype html>
<html lang="en">

<head>
    <title>TOMMY</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    <!-- Nucleo Icons -->
    <link href="./assets/css/nucleo-icons.css" rel="stylesheet" />
    <link href="./assets/css/nucleo-svg.css" rel="stylesheet" />
    <!-- Font Awesome Icons -->
    <link href="./assets/css/font-awesome.css" rel="stylesheet" />
    <link href="./assets/css/nucleo-svg.css" rel="stylesheet" />
    <!-- CSS Files -->
    <link href="./assets/css/argon-design-system.css?v=1.2.2" rel="stylesheet" />

</head>

<body class="bg-white">
    <nav id="navbar-main"
        class="navbar navbar-main navbar-expand-lg bg-white navbar-light position-sticky top-0 shadow py-2">
        <div class="container">
            <a class="navbar-brand mr-lg-5" href="index.php">
                <img src="./img/logo.png">
                <h3></h3>
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar_global"
                aria-controls="navbar_global" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="navbar-collapse collapse" id="navbar_global">
                <div class="navbar-collapse-header">
                    <div class="row">
                        <div class="col-6 collapse-brand">
                            <a href="index.php">
                                <img src="./img/logo.png">
                                <h3></h3>
                            </a>
                        </div>
                        <div class="col-6 collapse-close">
                            <button type="button" class="navbar-toggler" data-toggle="collapse"
                                data-target="#navbar_global" aria-controls="navbar_global" aria-expanded="false"
                                aria-label="Toggle navigation">
                                <span></span>
                                <span></span>
                            </button>
                        </div>
                    </div>
                </div>
                <!-- <p class="font-weight-bold">Basic example</p> -->

                <input class="form-control row-lg-4 mr-1 w-50 mr-5" id="search" name="search" type="search"
                    placeholder="Search Your Item...">

                <ul class="navbar-nav navbar-nav-hover align-items-lg-center float-md-start">
                    <li class="nav-item">
                        <select class="mdb-select md-form form-control " searchable="Search City..">
                            <option value="" disabled selected>Select Your City</option>
                            <option value="1">Hyderabad</option>
                            <option value="2">Delhi</option>
                            <option value="3">Bangloor</option>
                            <option value="3">andhra pradesh</option>
                            <option value="3">Usa</option>
                        </select>
                    </li>
                    <li class="nav-item d-none d-lg-block float">
                        <a href="#" target="_blank" class="btn btn-outline-primary btn-icon btn-md">
                            <span class="btn-inner--icon">
                                <i class="fa fa-user"></i>
                            </span>
                            <span class="nav-link-inner--text">Login</span>
                        </a>
                    </li>
                    <li class="nav-item d-none d-lg-block">
                        <a href="#" target="_blank" class="btn btn-outline-white btn-icon text-dark btn-md">
                            <span class="btn-inner--icon">
                                <i class="fa fa-plus"></i>
                            </span>
                            <span class="nav-link-inner--text">Post Add</span>
                        </a>
                    </li>
                </ul>

            </div>
        </div>
    </nav>

    <!-- main content -->

    <section id="gallery" class="mt-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 mb-4">
                    <div class="card">
                        <img src="./img/bmwx4.jpeg" class="p-1" alt="" width="" height="210px" class="card-img-top">
                        <div class="card-body">
                            <h5 class="card-title " style="font-family: arial;">$20,000</h5>
                            <span class="card-text" style="font-family: arial;"><b>New BMW X4 For Sell</b></span><br>
                            <span class="card-text" style="font-family: arial;">2020 model like brand new</span>
                            <a href="" class="btn btn-outline-primary btn-sm " style="font-family: arial;">Read More</a>
                            <a href="" class="btn btn-outline-white text-dark btn-sm" style="font-family: arial;"><i
                                    class="far fa-heart"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 mb-4">
                    <div class="card">
                        <img src="./img/iphone13.jpeg" class="p-1" alt="" width="" height="210px" class="card-img-top">
                        <div class="card-body">
                            <h5 class="card-title " style="font-family: arial;">$500</h5>
                            <span class="card-text" style="font-family: arial;"><b>APPLE IPHONE 13</b></span><br>
                            <span class="card-text" style="font-family: arial;">2021 model like brand new Mobile</span>
                            <a href="" class="btn btn-outline-primary btn-sm " style="font-family: arial;">Read More</a>
                            <a href="" class="btn btn-outline-white btn-sm text-dark" style="font-family: arial;"><i
                                    class="far fa-heart"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 mb-4">
                    <div class="card">
                        <img src="./img/bmwx4.jpeg" class="p-1" alt="" width="" height="210px" class="card-img-top">
                        <div class="card-body">
                            <h5 class="card-title " style="font-family: arial;">$25,000</h5>
                            <span class="card-text" style="font-family: arial;"><b>New BMW X5 For Sell</b></span><br>
                            <span class="card-text" style="font-family: arial;">2020 model like brand new</span>
                            <a href="" class="btn btn-outline-primary btn-sm " style="font-family: arial;">Read More</a>
                            <a href="" class="btn btn-outline-white text-dark btn-sm" style="font-family: arial;"><i
                                    class="far fa-heart"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 mb-4">
                    <div class="card">
                        <img src="./img/fzs.jpeg" class="p-1" alt="" width="" height="210px" class="card-img-top">
                        <div class="card-body">
                            <h5 class="card-title " style="font-family: arial;">$1,000</h5>
                            <span class="card-text" style="font-family: arial;"><b>used FZ 2.0 For Sell</b></span><br>
                            <span class="card-text" style="font-family: arial;">2020 model like brand new</span>
                            <a href="" class="btn btn-outline-primary btn-sm " style="font-family: arial;">Read More</a>
                            <a href="" class="btn btn-outline-white text-dark btn-sm" style="font-family: arial;"><i
                                    class="far fa-heart"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 mb-4">
                    <div class="card">
                        <img src="./img/bmwx4.jpeg" class="p-1" alt="" width="" height="210px" class="card-img-top">
                        <div class="card-body">
                            <h5 class="card-title " style="font-family: arial;">$28,000</h5>
                            <span class="card-text" style="font-family: arial;"><b>New BMW X1 For Sell</b></span><br>
                            <span class="card-text" style="font-family: arial;">2020 model like brand new</span>
                            <a href="" class="btn btn-outline-primary btn-sm " style="font-family: arial;">Read More</a>
                            <a href="" class="btn btn-outline-white text-dark btn-sm" style="font-family: arial;"><i
                                    class="far fa-heart"></i></a>
                        </div>
                    </div>
                </div>
            </div>
    </section>

    <!-- main content end -->

    <!-- footer start-->
    <!-- Remove the container if you want to extend the Footer to full width. -->
    <!-- Footer -->
    <footer class="text-center text-lg-start bg-primary text-white">
        <!-- Section: Social media -->
        <section class="d-flex justify-content-between p-4 bg-primary" >
            <!-- Left -->
            <div class="me-5">
                <span>Get connected with us on social networks:</span>
            </div>
            <!-- Left -->

            <!-- Right -->
            <div >
                <a href="" class="text-white me-4">
                    <i class="fab fa-facebook-f"></i>
                </a>
                <a href="" class="text-white me-4">
                    <i class="fab fa-twitter"></i>
                </a>
                <a href="" class="text-white me-4">
                    <i class="fab fa-google"></i>
                </a>
               
            </div>
            <!-- Right -->
        </section>
        <!-- Section: Social media -->

        <!-- Section: Links  -->
        <section class="">
            <div class="container text-center text-md-start mt-5">
                <!-- Grid row -->
                <div class="row mt-3">
                    <!-- Grid column -->
                    <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">
                        <!-- Content -->
                        <h6 class="text-uppercase fw-bold">Company name</h6>
                        <hr class="mb-4 mt-0 d-inline-block mx-auto"
                            style="width: 60px;  background-color: #7c4dff; height: 2px" />
                        <p>
                            Here you can use rows and columns to organize your footer
                            content. Lorem ipsum dolor sit amet, consectetur adipisicing
                            elit.
                        </p>
                    </div>
                    <!-- Grid column -->

                    <!-- Grid column -->
                    <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">
                        <!-- Links -->
                        <h6 class="text-uppercase fw-bold">Products</h6>
                        <hr class="mb-4 mt-0 d-inline-block mx-auto"
                            style="width: 60px; background-color: #7c4dff; height: 2px" />
                        <p>
                            <a href="#!" class="text-white">Team TOM</a>
                        </p>
                        <p>
                            <a href="#!" class="text-white">CMS PRODUCT</a>
                        </p>
                        <p>
                            <a href="#!" class="text-white">BUY AND SELL</a>
                        </p>
                        <p>
                            <a href="#!" class="text-white"></a>
                        </p>
                    </div>
                    <!-- Grid column -->

                    <!-- Grid column -->
                    <div class="col-md-3 col-lg-2 col-xl-2 mx-auto bg-primary mb-4 ">
                        <!-- Links -->
                        <h6 class="text-uppercase fw-bold">Useful links</h6>
                        <hr class="mb-4 mt-0 d-inline-block mx-auto"
                            style="width: 60px; background-color: #7c4dff; height: 2px" />
                        <p>
                            <a href="#!" class="text-white">Your Account</a>
                        </p>
                        <p>
                            <a href="#!" class="text-white">Become an Affiliate</a>
                        </p>
                        <p>
                            <a href="#!" class="text-white">Shipping Rates</a>
                        </p>
                        <p>
                            <a href="#!" class="text-white">Help</a>
                        </p>
                    </div>
                    <!-- Grid column -->

                    <!-- Grid column -->
                    <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
                        <!-- Links -->
                        <h6 class="text-uppercase fw-bold">Contact</h6>
                        <hr class="mb-4 mt-0 d-inline-block mx-auto"
                            style="width: 60px; background-color: #7c4dff; height: 2px" />
                        <p><i class="fas fa-home mr-3"></i> USA, NY 10012, US</p>
                        <p><i class="fas fa-envelope mr-3"></i> achyuth@email.com</p>
                        <p><i class="fas fa-phone mr-3" ></i> + 01 9912399123</p>
                    
                    </div>
                    <!-- Grid column -->
                </div>
                <!-- Grid row -->
            </div>
        </section>
        <!-- Section: Links  -->

        <!-- Copyright -->
        <div class="text-center p-3 bg-white text-dark">
            © 2020 Copyright:
            <a class="text-dark" href="#">OLX.com</a>
        </div>
        <!-- Copyright -->
    </footer>
    <!-- Footer -->

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="./assets/js/core/jquery.min.js" type="text/javascript"></script>
    <script src="./assets/js/core/popper.min.js" type="text/javascript"></script>
    <script src="./assets/js/core/bootstrap.min.js" type="text/javascript"></script>
    <script src="./assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
    <!--  Plugin for Switches, full documentation here: http://www.jque.re/plugins/version3/bootstrap.switch/ -->
    <script src="./assets/js/plugins/bootstrap-switch.js"></script>
    <!--  Plugin for the Sliders, full documentation here: http://refreshless.com/nouislider/ -->
    <script src="./assets/js/plugins/nouislider.min.js" type="text/javascript"></script>
    <script src="./assets/js/plugins/moment.min.js"></script>
    <script src="./assets/js/plugins/datetimepicker.js" type="text/javascript"></script>
    <script src="./assets/js/plugins/bootstrap-datepicker.min.js"></script>
    <!-- Control Center for Argon UI Kit: parallax effects, scripts for the example pages etc -->
    <!--  Google Maps Plugin    -->
    <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
    <script src="./assets/js/argon-design-system.min.js?v=1.2.2" type="text/javascript"></script>
    <script>
    function scrollToDownload() {

        if ($('.section-download').length != 0) {
            $("html, body").animate({
                scrollTop: $('.section-download').offset().top
            }, 1000);
        }
    }
    </script>
    <script src="https://cdn.trackjs.com/agent/v3/latest/t.js"></script>
    <script>
    window.TrackJS &&
        TrackJS.install({
            token: "ee6fab19c5a04ac1a32a645abde4613a",
            application: "argon-design-system-pro"
        });
    </script>
</body>

</html>