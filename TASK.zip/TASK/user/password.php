<?php
require "function.php";

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;


 global $today; 
$today = date("D d-F-Y");
function sendMail($email , $verify_code)
{
    require 'PHPMailer/Exception.php';
    require 'PHPMailer/SMTP.php';
    require 'PHPMailer/PHPMailer.php';
//Create an instance; passing `true` enables exceptions
    $mail = new PHPMailer(true);
    try {
        //Server settings
        //$mail->SMTPDebug = 0; 
        //$mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
        $mail->isSMTP();                                            //Send using SMTP
        $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
        $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
        $mail->Username   = 'achyuthkumark2000@gmail.com';                     //SMTP username
        $mail->Password   = 'qtoosgaiylnezmib';                             //SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
        $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
    
        //Recipients
        $mail->setFrom('achyuthkumark2000@gmail.com', 'TOMWHOCODES');
        $mail->addAddress($email);     //Add a recipient

    //Content

$mail->Subject = ' Email Verification From Team TOM  ';
$mail->Body    = '<head>
<style>
    .banner-color {
        background-color: #eb681f;
    }

    .title-color {
        color: #0066cc
    }

    .button-color {
        background-color: #0066cc;
    }

    @media screen and (min-width: 500px) {
        .banner-color {
            background-color: #0066cc;
        }

        .title-color {
            color: #eb681f;
        }

        .button-color {
            background-color: #eb681f;
        }
    }
</style>
</head>

<body>
<div style="background-color:#ececec;padding:0;margin:0 auto;font-weight:200;width:100%!important">
    <table align="center" border="0" cellspacing="0" cellpadding="0" style="table-layout:fixed;font-weight:200;font-family:Helvetica,Arial,sans-serif" width="100%">
        <tbody>
            <tr>
                <td align="center">
                    <center style="width:100%">
                        <table bgcolor="#FFFFFF" border="0" cellspacing="0" cellpadding="0" style="margin:0 auto;max-width:512px;font-weight:200;width:inherit;font-family:Helvetica,Arial,sans-serif" width="512">
                            <tbody>
                                <tr>
                                    <td bgcolor="#F3F3F3" width="100%" style="background-color:#f3f3f3;padding:12px;border-bottom:1px solid #ececec">
                                        <table border="0" cellspacing="0" cellpadding="0" style="font-weight:200;width:100%!important;font-family:Helvetica,Arial,sans-serif;min-width:100%!important" width="100%">
                                            <tbody>
                                                <tr>
                                                    <td align="left" valign="middle" width="50%"><span style="margin:0;color:#4c4c4c;white-space:normal;display:inline-block;text-decoration:none;font-size:12px;line-height:20px">TOMWHOCODES</span></td>
                                                    <td valign="middle" width="50%" align="right" style="padding:0 0 0 10px"><span style="margin:0;color:#4c4c4c;white-space:normal;display:inline-block;text-decoration:none;font-size:12px;line-height:20px">by Achyuth</span></td>
<td width="1">&nbsp;</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td align="left">
<table border="0" cellspacing="0" cellpadding="0" style="font-weight:200;font-family:Helvetica,Arial,sans-serif" width="100%">
    <tbody>
        <tr>
            <td width="100%">
                <table border="0" cellspacing="0" cellpadding="0" style="font-weight:200;font-family:Helvetica,Arial,sans-serif" width="100%">
                    <tbody>
                        <tr>
                            <td align="center" bgcolor="#8BC34A" style="padding:20px 48px;color:#ffffff" class="banner-color">
                                <table border="0" cellspacing="0" cellpadding="0" style="font-weight:200;font-family:Helvetica,Arial,sans-serif" width="100%">
                                    <tbody>
                                        <tr>
                                            <td align="center" width="100%">
                                                <h1 style="padding:0;margin:0;color:#ffffff;font-weight:500;font-size:20px;line-height:24px">Password Reset Link</h1>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td align="center" style="padding:20px 0 10px 0">
                                <table border="0" cellspacing="0" cellpadding="0" style="font-weight:200;font-family:Helvetica,Arial,sans-serif" width="100%">
                                    <tbody>
                                        <tr>
                                            <td align="center" width="100%" style="padding: 0 15px;text-align: justify;color: rgb(76, 76, 76);font-size: 12px;line-height: 18px;">
                                                <h3 style="font-weight: 600; padding: 0px; margin: 0px; font-size: 16px; line-height: 24px; text-align: center;" class="title-color">Hai. Welcome..! ' .$_POST["email"].' </h3>
                                                <p style="margin: 20px 0 30px 0;font-size: 15px;text-align: center;"> click on Reset Button to <b>Create New Password</b>!</p>
                                                <div style="font-weight: 200; text-align: center; margin: 25px;"><a style="padding:0.6em 1em;border-radius:600px;color:#ffffff;font-size:14px;text-decoration:none;font-weight:bold" class="button-color" href="http://localhost/TASK/user/forgot_password.php?email='.$email.'">Reset Password Now</a>

                                                </div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                        <tr>
                        </tr>
                        <tr>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>
    </tbody>
</table>
</td>
</tr>
<tr>
<td align="left">
<table bgcolor="#FFFFFF" border="0" cellspacing="0" cellpadding="0" style="padding:0 24px;color:#999999;font-weight:200;font-family:Helvetica,Arial,sans-serif" width="100%">
    <tbody>
        <tr>
            <td align="center" width="100%">
                <table border="0" cellspacing="0" cellpadding="0" style="font-weight:200;font-family:Helvetica,Arial,sans-serif" width="100%">
                    <tbody>
                        <tr>
                            <td align="center" valign="middle" width="100%" style="border-top:1px solid #d9d9d9;padding:12px 0px 20px 0px;text-align:center;color:#4c4c4c;font-weight:200;font-size:12px;line-height:18px">Regards,
                                <br><b>Team TOMWHOCODES</b>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>
        <tr>
            <td align="center" width="100%">
                <table border="0" cellspacing="0" cellpadding="0" style="font-weight:200;font-family:Helvetica,Arial,sans-serif" width="100%">
                    <tbody>
                        <tr>
                            <td align="center" style="padding:0 0 8px 0" width="100%"></td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>
    </tbody>
</table>
</td>
</tr>
</tbody>
</table>
</center>
</td>
</tr>
</tbody>
</table>
</div>
</body>';
$mail->isHTML(true); //Set email format to HTML
$mail->AltBody = 'click verify to complete the verification process';
$mail->send();
return true;
}
catch (Exception $e) {
echo "Message could not be sent. Mailer Error: { $mail->ErrorInfo }";
return false;
}

}
$verify_code = bin2hex(random_bytes(16));

if(isset($_POST["submit"]))
{
$email = $_POST['email'];

if (!empty($email))
{
$verify_status = 0;

// $sql = "INSERT INTO verify_email(id,firstname,lastname,email,verify_code,verify_status) VALUES(' ','$firstname','$lastname','$email','$verify_code','$verify_status')";
if(sendMail($_POST['email'],$verify_code))
{
    echo '<style type="text/css">#hidediv{
        display:none;
        }</style>';

    echo '
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" />
<section class="mail-seccess section m-5">
	<div class="container">
		<div class="row">
			<div class="col-lg-6 offset-lg-3 col-12">
				<!-- Error Inner -->
				<div class="success-inner">
					<h1><i class="fa fa-envelope"></i><span>Reset Request Mail Sent Successfully! to <p>'.$_POST['email'].'</p></span></h1>
					<p>Now You can Ckeck the Given Mail To Reset Your Password Thankyou..!</p>
					<a href="login.php" class="btn btn-primary btn-lg">Go Home</a>
				</div>
				<!--/ End Error Inner -->
			</div>
		</div>
	</div>
</section>';
}
else {
echo "<script>alert('Email Failed to Send');</script>";
}

}
else {
echo "<script>
    alert('Please Fill ALL the FIeldsFAILED');

</script>".$email->ErrorInfo;

}

}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Password Reset - SB Admin</title>
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
</head>

<body>
<div id="hidediv" class="bg-dark">
<div id="layoutAuthentication">
            <div id="layoutAuthentication_content">
                <main>
                    <div class="container ">
                        <div class="row justify-content-center">
                            <div class="col-lg-5">
                                <div class="card shadow-lg border-0 rounded-lg mt-5 ">
                                    <div class="card-header "><h3 class="text-center font-weight-light my-4">Password Reset</h3></div>
                                    <div class="card-body">
                                        <form method="post" autocomplete="off" action="" class="form-group">
										                        <input type="hidden" id="action" value="login" class='form-control'>
                                            <div class="form-floating mb-3" style="width:95%">
                                                <input class="form-control" id="email"  name="email" type="email" placeholder="name@example.com" />
                                                <label for="username">Email address</label>
                                            </div>
                                            <div class="d-flex align-items-center justify-content-between mt-4 mb-0">
                                               <input type="submit" value="Reset" class='btn btn-dark bg-dark'" name="submit" onclick="ValidateEmail();" />
                                                
                                            </div>
                                        </form>
                                    </div>
                                    <div class="card-footer text-center py-3">
                                        
                                        <div class="small"><a href="login.php">Login.!</a></div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
        </div>
        
</div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous">
    </script>
</body>
    <script src="js/scripts.js"></script>
    <script type="text/javascript">
    function ValidateEmail(inputText) {
        var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
        if (inputText.value.match(mailformat)) {
            alert("Valid email address!");
            document.form1.text1.focus();
            return true;
        } else {
            alert("You have entered an invalid email address!");
            document.form1.text1.focus();
            return false;
        }
    }
    </script>

</body>

</html>


       

