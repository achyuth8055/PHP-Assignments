<?php
require 'function.php';
// require 'required.php';

  


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Home.php</title>
    <!-- Favicon-->
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
    <!-- Core theme CSS (includes Bootstrap)-->
    <link href="css/styles.css" rel="stylesheet" />
</head>

<body class="bg-dark">
    <!-- Responsive navbar-->

    <nav class="navbar navbar-expand-xlg sticky-top navbar-dark bg-dark">
        <div class="container"><?php if(!isset($_SESSION['id'])){ ?>
            <a class="navbar-brand" href="index.php">Home</a>
            <?php }else{  $id = $_SESSION['id']; $name = mysqli_fetch_assoc($query = mysqli_query($conn, "SELECT * FROM tb_user WHERE id = $id")); ?>



            <a class="navbar-brand text-capitalize" href="index.php"><small class="h6">welcome
                </small><?php echo $name['firstname'];?></a>

            <?php }?>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
            <div class=" container text-center">

                <h1 class="text-light text-capitalize"><?php //echo $row['firstname']?></h1>
            </div>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <?php 
      if(!isset($_SESSION['id']))
      {
           
      ?>
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item"><a class="nav-link" href="login.php">Login</a>
                    </li>
                    <li class="nav-item"><a class="nav-link" href="register.php">Register</a></li>
                    <!-- <li class="nav-item"><a class="nav-link" href="#!">Contact</a></li> 
                        <li class="nav-item"><a class="nav-link active" aria-current="page" href="#">Blog</a></li> -->
                </ul>
                <?php 
}else{ ?>

                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item"><a class="nav-link" href="profile.php"><i
                                class="fa fa-user class-light"></i>Profile</a></li>
                    <li class="nav-item"><a class="nav-link" href="addpost.php"><i
                                class="fa fa-tachometer class-light"></i>Creat New Post</a></li>
                    <li class="nav-item"><a class="nav-link" href="home.php"><i
                                class="fa fa-tachometer class-light"></i>DashBoard</a></li>

                    <li class="nav-item"><a class="nav-link" href="logout.php"><i
                                class="fa fa-tachometer class-light"></i>Logout</a></li>
                </ul><?php } global $user;
                                $user = mysqli_fetch_assoc($query = mysqli_query($conn, "SELECT * FROM post "));?>
            </div>
        </div>
    </nav>
    <!-- Page header with logo and tagline-->
    <header class="py-2 bg-dark border-bottom mb-4">
        <div class="container bg-dark">

        </div>
    </header>
    <!-- Page content-->

    <?php
              
           echo ' <div class="row m-4 bg-dark ">';
                       
                global $user;
                foreach($query as $user){
                 ?>


    <div class="col-md-3 bg-dark">
        <form class="form-group" method="post" action="">
            <div class="card mb-4 p-2 h-75">
                <div class="" name="center-block text-center mh-50">
                    <a href="#!" class="h-75"><img class="card-img-top img-fluid w-100 rounded" style="height:200px;"
                            src='<?php echo $user['img']?>' alt="REVIEW IMAGE" /></a>
                    <div class="card-body">
                        <div class="small text-muted text-capitalize">
                            <?php echo "Uploaded on ".$user['timestamp']." by ".$user['author']?></div>
                        <input type="hidden" value="<?php echo $user['id'] ?>" name="id">
                        <h2 class="card-title h4 text-uppercase"><?php echo $user['title'] ?></h2>
                        <p class="card-text text-capitalize" style="
                                    overflow: hidden;
   text-overflow: ellipsis;
   display: -webkit-box;
   -webkit-line-clamp: 2; /* number of lines to show */
   -webkit-box-orient: vertical;">
                            <?php echo $user['textcontent']?>
                        </p>
                        <button class="btn" type="submit">
                            <?php echo '<a href="./post/preview.php?id='.$user["id"].'&aid='.$user['author_id'].'" class="btn btn-outline-dark"> Read more →</a>';?>
                        </button>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <!-- Blog post-->
    <?php } ?>
    </div>

    <!-- Footer-->
    <footer class="py-3 bg-dark " width="100%">
        <div class="container w-100" width="100%">
            <p class="m-0 text-center text-light"> Copyright &copy; Your Website 2022</p>

        </div>
    </footer>
    <!-- Bootstrap core JS-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Core theme JS-->
    <script src="js/scripts.js"></script>

</body>
<script>
function dis(e) {
    console.log('button clicked');
    event.preventDefault();

}
</script>

</html>