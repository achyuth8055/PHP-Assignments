<?php
require 'function.php';
global $user;
global $tid;
global $result;
global $conn;
global $tid;
$admin = mysqli_fetch_assoc($query = mysqli_query($conn, "SELECT * FROM admin"));  
if(isset($_SESSION["id"]))
  {
 $tid = $_SESSION['id'];
 if(isset($_GET['id']))
 {
      global $pid;
      $pid = $_GET['id'];
      $author = mysqli_fetch_assoc($query = mysqli_query($conn, "SELECT * FROM tb_user WHERE id = {$tid}"));
      $user = mysqli_fetch_assoc($query = mysqli_query($conn, "SELECT * FROM post WHERE id = {$pid}"));  
      $a_id = $user['author_id'];
      $u_id = $_SESSION['id'];  
  if($a_id == $u_id)
  {
    // echo "if authorized authord is requested for edit";
     if(isset($_POST['submit']))
     {

  $img_name = $_FILES['img_upload']['name'];
  $tmp_img_name = $_FILES['img_upload']['tmp_name'];
  $folder = "img_folder/";
  $ext = explode('.', $img_name);
  $file_name = $ext[0];
  $file_ext = $ext[1];
  $img_url = $folder.$file_name.'_' .time().'.'.$file_ext;
  $title = $_POST['title'];
  $textcontent = mysqli_real_escape_string($conn,$_POST['textcontent']);
  $author_name = $post['firstname'];
  $author_id =  $post['id']; 
  //move_uploaded_file($tmp_img_name,$folder.$img_name);
  if(isset($_GET['id'])){  
      $id = $_GET['id'];
  if(empty($title))
      {
  echo "<script>alert('Please FILL DEATILES')</script>";
  exit;
}

  else { 
       //echo $id;
       $sql = "SELECT * FROM post WHERE (id = '$pid')";
       $query = mysqli_query($conn,$sql);         
       if(mysqli_fetch_array($query) > 0)
       {		  
          $img_name = $_FILES['img_upload']['name'];
          $tmp_img_name = $_FILES['img_upload']['tmp_name'];
          $folder = "img_folder/";
          $ext = explode('.', $img_name);
          $file_name = $ext[0];
          $file_ext = $ext[1];
          $img_url = $folder.$file_name.'_' .time().'.'.$file_ext;
          move_uploaded_file($tmp_img_name,$img_url);
            $sql = "UPDATE post SET img = '$img_url' , author_id = '$author_id' , title = '$title' , textcontent = '$textcontent',timestamp=now() WHERE id = '$pid'";
            $query = mysqli_query($conn,$sql);
            if($query)
            {
                echo "<script> alert('POST updated') </script>"; 
                header("Location:index.php");
           
           }

           else if(0)
           {  
                      echo "<script> alert('POST NOT UPDATED')</script>";
                   }
       }}}}   
      //fetch image if exist 
      if(isset($_GET['id']))
      {
      $img_id = $_GET['id'];
      $sql = "SELECT * FROM post WHERE id = {$img_id}";
      $result = mysqli_query($conn,$sql);        
      while ($img_row = mysqli_fetch_array($result))
      {
          $img_url = $img_row['img'];
          $post_name = $img_row['author'];
          $title_update = $img_row['title'];
          $textcontent_update = $img_row['textcontent'];             
      }
      }
 }  
 else if($a_id != $u_id)
 {
  header("Location:unauthorized.php");

}
 }

   else if(!(isset($_POST['id'])))
  { 
      header("Location:unauthorized.php");

}



}  






?>
<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="utf-8">
    <title>Home</title>
</head>

<body>

</body>

</html>

<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Dashboard</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
		 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
		
        
        <style type="text/css">
		body {
             font-family: arial;
             }
            .hide{
			display: none;
				}
		
		</style>
    </head>
    <body class="sb-nav-fixed">
        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <!-- Navbar Brand-->
            <a class="navbar-brand ps-3" href="index.php">Home</a>
            <!-- Sidebar Toggle-->
            <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
            <!-- Navbar Search-->
            <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
                <div class="input-group">
                    <!--<input class="form-control" type="text" placeholder="Search for..." aria-label="Search for..." aria-describedby="btnNavbarSearch" />
                    <button class="btn btn-primary" id="btnNavbarSearch" type="button"><i class="fas fa-search"></i></button>
                --></div>
            </form>
            <!-- Navbar-->
            <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="profile.php"><b><?php echo $author["firstname"];?></b></a></li>
                        <li><a class="dropdown-item" href="#!"></a></li>
                        <li><hr class="dropdown-divider" /></li>
                        <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <div class="sb-sidenav-menu-heading">Profile Photo</div>
                            <a class="nav-link text-capitalize" href="profile.php">
                                <div class="sb-nav-link-icon text-light text-center">
                                    <img src="<?php echo $author['profile_img']?>" alt="profile_photo" class="img-thumbnail ml-4 col" style="border-radius: 50%; height : 120px; width : 120px;"/><!--<i class="as fa-user"></i>-->
                                <p><?php echo "<h5>".$author['firstname']."</h5>"; if($author['account_state']=='1'){ echo '<i class="fas fa-check-circle" title="verified">'; }else{ echo '<i class="fa-solid fa-ban" title="not A verified Account"></i>';} ?></i></p>
                                </div>
                        
                            </a>                            
                            <div class="collapse" id="collapsePages" aria-labelledby="headingTwo" data-bs-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav accordion" id="sidenavAccordionPages">
                                    </nav>
                            </div>
                            <div class="sb-sidenav-menu-heading">Post Related</div>
                            <a class="nav-link" href="post/home.php">
                                <div class="sb-nav-link-icon"><i class="fa-solid fa-file"></i></div>
                                View all Post
                            </a>
                            <a class="nav-link" href="addpost.php">
                                <div class="sb-nav-link-icon"><i class="fa-solid fa-file-text" aria-hidden="true"></i></div>
                                Create New
                            </a>                            
                        </div>
                    </div>
                    <div class="sb-sidenav-footer">
                        <div class="small text-capitalize">Loggedin as: <?php echo $author["firstname"];echo " ";echo $author['lastname']?></div>
                        
                    </div>
                    
                </nav>
            </div>
            <!--content hre to -->

            <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-7">
                <div class="card shadow-lg border-0 rounded-lg mt-5 bg-light">
                    <div class="card-header bg-light">
                        <h3 class="text-center font-weight-light my-2"></h3>
                    </div>
                    <form action="" method="POST" class="form-group m-4 " enctype="multipart/form-data">
                        <div class="card w-100 text-center aligh-center" >
                            <img class="card-img-top text-capitalize w-100 rounded p-2 rounded" alt="photo" id="output"
                                src="<?php echo $img_url; ?>"
                                title="<?php echo " Review by :". $post_name;?>" height="300px"/>
                            <div class="card-body">
                                <h5 class="card-title">Select Image from Pc</h5>
                                <input type="file" name="img_upload" class="custom-file form-control-file form-control" id="img_upload" accept="image/*" onchange="loadFile(event)" required>
                            </div>
                        </div>
                        <div class="card-body">                     
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <div class="form-floating mb-3 mb-md-0">
                                        <input class="form-control text-capitalize" id="author_name" name="author_name"
                                            type="text" value="<?php echo $post_name; ?>" disabled />
                                        <label for="author">Author</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <input class="form-control text-uppercase" id="title" name="title" type="text" value="<?php echo $title_update ?>"/>
                                        <label for="title" class="form-lable text-capitalize">Post Title</label>
                                    </div>
                                </div>
                            </div>
                            <div class="form-floating mb-3">                               
                            </div>
                        </div>
                        <div class="row lg-3 p-1">
                                    <div class="form-floating mb-2">
                                        <div id="textcontentlable" class="hide col-xs-2" name="hide">
                                            <label for="textcontent" class="form-lable">Review Text Content</label>                                            
                                        </div>
                                        <textarea class="form-control" placeholder="Review Content Here"
                                            style="height:100%" rows="6" cols="500" id="textcontent"  name="textcontent"
                                            type="text" maxlength="8000"> <?php echo $textcontent_update ?> </textarea>
                                    </div>
                                    <span id="message"></span>
                                </div>
                                <div class="mt-4 mb-0">
                                    <div class="d-grid mb-2">
                                        <input type="hidden" id="action" value="addpost" class='form-control'>
                                        <input type="submit" class="btn btn-md btn-primary btn-block form-group"
                                            onclick="" id='submit' value="submit" name='submit' />
                                    </div>
                                </div>
                    </form>
                    </div>
            </div>
        </div>
    </div>



            <!--to here  -->
        </div>
        <script>
var loadFile = function(event) {
    var output = document.getElementById('output');
    output.src = URL.createObjectURL(event.target.files[0]);
    output.onload = function() {
        URL.revokeObjectURL(output.src);
    }
};
</script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script> -->
        <!-- <script src="assets/demo/chart-area-demo.js"></script> -->
        <!-- <script src="assets/demo/chart-bar-demo.js"></script> -->
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
    </body>
</html>
