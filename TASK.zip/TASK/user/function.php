 <?php
session_start();
global $conn;
global $author;
global $user_id;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

 global $today; 
$today = date("D d-F-Y");
$conn = mysqli_connect("localhost", "root", "", "testing");
if(isset($_SESSION["id"]))
{     
  $user_id = $_SESSION["id"];
}

$user = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM tb_user WHERE id ='$user_id'"));

// if(isset($user_id))
// {
//   $user = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM tb_user WHERE id ='$user_id'"));

//   // $author = $user['firstname'];
// }// IF

if(isset($_POST["action"]))
{ 
  if($_POST["action"] == "register")
  {
    register();
  }
  else if($_POST["action"] == "login")
  {
    login();
  }
  else if($_POST["action"] == "update")
  {
    edit_data();
  }
  else if($_POST["action"] == "edit_post")
  {
    edit_post();
  } 
}
//post new blog
  function post_blog()
  {
	 echo "working post blog section complete query to upload post";	
  }
  
// REGISTER
function register(){
  global $conn;
  $firstname = $_POST["firstname"];
  $lastname = $_POST["lastname"];
  $email = $_POST["username"];
  $password = $_POST["password"];
  $confirm_password = $_POST["confirm_password"];
  $role = $_POST["role"];
  $address = $_POST["address"];
  $phone = $_POST["phone"]; 

  if(empty($firstname) || empty($email) || empty($password) || empty($phone) || empty($role) || empty($address) || empty($lastname)){
    echo "Please Fill Out The Form!";
    exit;
  }//checkinh the empty fields

  $url = file_get_contents("https://emailvalidation.abstractapi.com/v1/?api_key=71679347745d4948ae961c9837598409&email=$email");
  $data = json_decode($url,true);
  // print_r()$data;
  $valid = $data['is_valid_format']['text'];
  $deliverable = $data['deliverability'];  
  
  if($valid == true){
      if($deliverable == 'DELIVERABLE')
      {
           //next process
           $qury = "SELECT * FROM tb_user WHERE username = '$email'";
           $user = mysqli_query($conn, $qury);
          if(mysqli_num_rows($user) > 0)
            {
              echo '';
               echo "User Exist Already";
              exit;
             }
     if($password == $confirm_password){

       $verify_code = bin2hex(random_bytes(16));
       $account_state = 0;

       $query = "INSERT INTO tb_user(id , firstname , lastname , username , password , role , address,phone,verify_code,account_state) VALUES('','$firstname','$lastname','$email', '$password','$role','$address','$phone','$verify_code','$account_state')";
       // $query = "INSERT INTO tb_user(firstname , lastname , username , password , role , address) VALUES('','$firstname','$lastname','$username', '$password','$role','$address')";
       $res = mysqli_query($conn, $query); 
       if($res)
       { 
         
          
        require 'PHPMailer/Exception.php';
        require 'PHPMailer/SMTP.php';
        require 'PHPMailer/PHPMailer.php';
    
    //Create an instance; passing `true` enables exceptions
        $mail = new PHPMailer(true);
        try {
        //Server settings
        //$mail->SMTPDebug = 0; 
        //$mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
        $mail->isSMTP();                                            //Send using SMTP
        $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
        $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
        $mail->Username   = 'achyuthkumark2000@gmail.com';                     //SMTP username
        $mail->Password   = 'Achyuth@12512';                             //SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
        $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
    
        //Recipients
        $mail->setFrom('achyuthkumark2000@gmail.com', 'TOMWHOCODES');
        $mail->addAddress($email);     //Add a recipient
    
        //Content
    
        $mail->Subject = 'Email Verification From Team TOM';
        $mail->Body    = '<head>
        <style>
            .banner-color {
                background-color: #eb681f;
            }
        
            .title-color {
                color: #0066cc
            }
        
            .button-color {
                background-color: #0066cc;
            }
        
            @media screen and (min-width: 500px) {
                .banner-color {
                    background-color: #0066cc;
                }
        
                .title-color {
                    color: #eb681f;
                }
        
                .button-color {
                    background-color: #eb681f;
                }
            }
        </style>
        </head>
        
        <body>
        <div style="background-color:#ececec;padding:0;margin:0 auto;font-weight:200;width:100%!important">
            <table align="center" border="0" cellspacing="0" cellpadding="0" style="table-layout:fixed;font-weight:200;font-family:Helvetica,Arial,sans-serif" width="100%">
                <tbody>
                    <tr>
                        <td align="center">
                            <center style="width:100%">
                                <table bgcolor="#FFFFFF" border="0" cellspacing="0" cellpadding="0" style="margin:0 auto;max-width:512px;font-weight:200;width:inherit;font-family:Helvetica,Arial,sans-serif" width="512">
                                    <tbody>
                                        <tr>
                                            <td bgcolor="#F3F3F3" width="100%" style="background-color:#f3f3f3;padding:12px;border-bottom:1px solid #ececec">
                                                <table border="0" cellspacing="0" cellpadding="0" style="font-weight:200;width:100%!important;font-family:Helvetica,Arial,sans-serif;min-width:100%!important" width="100%">
                                                    <tbody>
                                                        <tr>
                                                            <td align="left" valign="middle" width="50%"><span style="margin:0;color:#4c4c4c;white-space:normal;display:inline-block;text-decoration:none;font-size:12px;line-height:20px">TOMWHOCODES</span></td>
                                                            <td valign="middle" width="50%" align="right" style="padding:0 0 0 10px"><span style="margin:0;color:#4c4c4c;white-space:normal;display:inline-block;text-decoration:none;font-size:12px;line-height:20px">by Achyuth</span></td>
        <td width="1">&nbsp;</td>
        </tr>
        </tbody>
        </table>
        </td>
        </tr>
        <tr>
        <td align="left">
        <table border="0" cellspacing="0" cellpadding="0" style="font-weight:200;font-family:Helvetica,Arial,sans-serif" width="100%">
            <tbody>
                <tr>
                    <td width="100%">
                        <table border="0" cellspacing="0" cellpadding="0" style="font-weight:200;font-family:Helvetica,Arial,sans-serif" width="100%">
                            <tbody>
                                <tr>
                                    <td align="center" bgcolor="#8BC34A" style="padding:20px 48px;color:#ffffff" class="banner-color">
                                        <table border="0" cellspacing="0" cellpadding="0" style="font-weight:200;font-family:Helvetica,Arial,sans-serif" width="100%">
                                            <tbody>
                                                <tr>
                                                    <td align="center" width="100%">
                                                        <h1 style="padding:0;margin:0;color:#ffffff;font-weight:500;font-size:20px;line-height:24px">Email Verification Link</h1>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="center" style="padding:20px 0 10px 0">
                                        <table border="0" cellspacing="0" cellpadding="0" style="font-weight:200;font-family:Helvetica,Arial,sans-serif" width="100%">
                                            <tbody>
                                                <tr>
                                                    <td align="center" width="100%" style="padding: 0 15px;text-align: justify;color: rgb(76, 76, 76);font-size: 12px;line-height: 18px;">
                                                        <h3 style="font-weight: 600; padding: 0px; margin: 0px; font-size: 16px; line-height: 24px; text-align: center;" class="title-color">Hai. Welcome..! ' .$_POST["firstname"].' </h3>
                                                        <p style="margin: 20px 0 30px 0;font-size: 15px;text-align: center;">Thank you For Registration Please click on Verify Button to <b>Complete Registration</b>!</p>
                                                        <div style="font-weight: 200; text-align: center; margin: 25px;"><a style="padding:0.6em 1em;border-radius:600px;color:#ffffff;font-size:14px;text-decoration:none;font-weight:bold" class="button-color" href="http://localhost/geny/new/verify.php?email='.$email.'&verify_code='.$verify_code.'">Verify Now</a>
        
                                                        </div>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                </tr>
                                <tr>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
        </td>
        </tr>
        <tr>
        <td align="left">
        <table bgcolor="#FFFFFF" border="0" cellspacing="0" cellpadding="0" style="padding:0 24px;color:#999999;font-weight:200;font-family:Helvetica,Arial,sans-serif" width="100%">
            <tbody>
                <tr>
                    <td align="center" width="100%">
                        <table border="0" cellspacing="0" cellpadding="0" style="font-weight:200;font-family:Helvetica,Arial,sans-serif" width="100%">
                            <tbody>
                                <tr>
                                    <td align="center" valign="middle" width="100%" style="border-top:1px solid #d9d9d9;padding:12px 0px 20px 0px;text-align:center;color:#4c4c4c;font-weight:200;font-size:12px;line-height:18px">Regards,
                                        <br><b>Team TOMWHOCODES</b>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td align="center" width="100%">
                        <table border="0" cellspacing="0" cellpadding="0" style="font-weight:200;font-family:Helvetica,Arial,sans-serif" width="100%">
                            <tbody>
                                <tr>
                                    <td align="center" style="padding:0 0 8px 0" width="100%"></td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
        </td>
        </tr>
        </tbody>
        </table>
        </center>
        </td>
        </tr>
        </tbody>
        </table>
        </div>
        </body>';
    $mail->isHTML(true); //Set email format to HTML
    $mail->AltBody = 'click verify to complete the verification process';
    $mail->send();
    return true;
    }
    catch (Exception $e) {
    //echo "Message could not be sent. Mailer Error: { $mail->ErrorInfo }";
    return false;
    }
    echo "Registration Successful check Mail to Verify The Email";
    
    }

        //  echo "Registration Successful check Mail to Verify The Email";
       
       }
     }
     
     else { 
       
      echo "This Mail Don't Exist";     
    
    }

      }
      else{

      echo "Invalid Email Not Deleverable";
      }

    }


// LOGIN
function login(){
  global $conn;
  $username = $_POST["username"]; 
  $password = $_POST["password"];
  if($username == '' || $password=='')
  {
      echo "Please Enter Username and Password";
  }
  else{
  $query = "SELECT * FROM tb_user WHERE username = '$username'";
  $user = mysqli_query($conn,$query);
  if(mysqli_num_rows($user) > 0)
  {
    $row = mysqli_fetch_assoc($user);
    if($username == $row['username'] && $password == $row['password'])
    {
      $_SESSION["login"] = true;
      $_SESSION["id"] = $row["id"];
      echo "Login Successful"; 
    }
    else{
    echo "Wrong Password";   
  }
} 
else{
  echo "Not Registered";
  exit;
}
}
}
//edit profile data php
     function edit_data()
     {
      global $conn;
      if(!$conn) {die("Connection failed: " . mysqli_connect_error());}
          $firstname = $_POST['firstname']; 
          $username = $_POST['username'];
          $address = $_POST['address']; 
          $phone = $_POST['phone'];
          $sql = "UPDATE tb_user SET firstname = '$firstname', phone = '$phone' , address = '$address'  WHERE username = '$username'";
          $query = mysqli_query($conn, $sql);
      if ($query) 
      {
       
        echo "Record updated successfully";
      } 

      else {
        echo "Error updating record: " . mysqli_error($conn);
      }

      mysqli_close($conn);
  }

  //edit.php post data php
  function edit_post(){

    global $conn;
    if(!$conn) {
      die("Connection failed: " . mysqli_connect_error());
    }
    
    $id = $_POST['id']; 
    $title = $_POST['username'];
    $textcontent = $_POST['address']; 
    //$img_url = $_POST['phone'];  
    $sql = "UPDATE post SET title='$title',textcontent = '$textcontent'";
    $query = mysqli_query($conn, $sql);
    if ($query) {
      echo "Post updated successfully";
    } else {
      echo "Error in updating Post Try After Some Time: " . mysqli_error($conn);
    }
    
    mysqli_close($conn);
}


  
  


?>