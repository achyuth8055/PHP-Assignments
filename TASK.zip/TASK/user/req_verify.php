<?php
$message ="";
session_start();
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
require 'PHPMailer/Exception.php';
require 'PHPMailer/SMTP.php';
require 'PHPMailer/PHPMailer.php';


    if (isset($_GET["email"]) && isset($_GET["verify_code"]) || isset($_POST["email"]))
     {
        
            $update = "UPDATE tb_user SET verify_code=";
            $email = $_GET["email"];
           // $email = $_POST["email"];
            unset($_SESSION["verify_code"]);
            $_SESSION['verify_code'] = $_GET['verify_code'];
            $verify_code = $_SESSION['verify_code']; 
            if($verify_code != $_SESSION['verify_code'])
            {
                echo "secession Expired";
                die();
            }
            
            if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
            
                    
            // $url = file_get_contents("https://emailvalidation.abstractapi.com/v1/?api_key=71679347745d4948ae961c9837598409&email=$email");
            // $data = json_decode($url,true);
            // // print_r()$data;
            // $valid = $data['is_valid_format']['text'];
            // $deliverable = $data['deliverability'];         
            // if($valid == "TRUE"){
            //     if($deliverable == 'DELIVERABLE')
            //     {
                     global $today; 
                    $today = date("D d-F-Y");      
                    //Create an instance; passing `true` enables exceptions
                        $mail = new PHPMailer(true);
                        try {
                        //Server settings
                        //$mail->SMTPDebug = 0; 
                        //$mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
                        $mail->isSMTP();                                            //Send using SMTP
                        $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
                        $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
                        $mail->Username   = 'achyuthkumark2000@gmail.com';                     //SMTP username
                        $mail->Password   = 'qtoosgaiylnezmib';                             //SMTP password
                        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
                        $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
                        //Recipients
                        $mail->setFrom('achyuthkumark2000@gmail.com', 'TOMWHOCODES');
                        $mail->addAddress($email);     //Add a recipient
                    
                        //Content
                    
                        $mail->Subject = 'Email Verification From Team TOM';
                        $mail->Body    = '<head>
                        <style>
                            .banner-color {
                                background-color: #eb681f;
                            }
                        
                            .title-color {
                                color: #0066cc
                            }
                        
                            .button-color {
                                background-color: #0066cc;
                            }
                        
                            @media screen and (min-width: 500px) {
                                .banner-color {
                                    background-color: #0066cc;
                                }
                        
                                .title-color {
                                    color: #eb681f;
                                }
                        
                                .button-color {
                                    background-color: #eb681f;
                                }
                            }
                        </style>
                        </head>
                        
                        <body>
                        <div style="background-color:#ececec;padding:0;margin:0 auto;font-weight:200;width:100%!important">
                            <table align="center" border="0" cellspacing="0" cellpadding="0" style="table-layout:fixed;font-weight:200;font-family:Helvetica,Arial,sans-serif" width="100%">
                                <tbody>
                                    <tr>
                                        <td align="center">
                                            <center style="width:100%">
                                                <table bgcolor="#FFFFFF" border="0" cellspacing="0" cellpadding="0" style="margin:0 auto;max-width:512px;font-weight:200;width:inherit;font-family:Helvetica,Arial,sans-serif" width="512">
                                                    <tbody>
                                                        <tr>
                                                            <td bgcolor="#F3F3F3" width="100%" style="background-color:#f3f3f3;padding:12px;border-bottom:1px solid #ececec">
                                                                <table border="0" cellspacing="0" cellpadding="0" style="font-weight:200;width:100%!important;font-family:Helvetica,Arial,sans-serif;min-width:100%!important" width="100%">
                                                                    <tbody>
                                                                        <tr>
                                                                            <td align="left" valign="middle" width="50%"><span style="margin:0;color:#4c4c4c;white-space:normal;display:inline-block;text-decoration:none;font-size:12px;line-height:20px">TOMWHOCODES</span></td>
                                                                            <td valign="middle" width="50%" align="right" style="padding:0 0 0 10px"><span style="margin:0;color:#4c4c4c;white-space:normal;display:inline-block;text-decoration:none;font-size:12px;line-height:20px">by Achyuth</span></td>
                        <td width="1">&nbsp;</td>
                        </tr>
                        </tbody>
                        </table>
                        </td>
                        </tr>
                        <tr>
                        <td align="left">
                        <table border="0" cellspacing="0" cellpadding="0" style="font-weight:200;font-family:Helvetica,Arial,sans-serif" width="100%">
                            <tbody>
                                <tr>
                                    <td width="100%">
                                        <table border="0" cellspacing="0" cellpadding="0" style="font-weight:200;font-family:Helvetica,Arial,sans-serif" width="100%">
                                            <tbody>
                                                <tr>
                                                    <td align="center" bgcolor="#8BC34A" style="padding:20px 48px;color:#ffffff" class="banner-color">
                                                        <table border="0" cellspacing="0" cellpadding="0" style="font-weight:200;font-family:Helvetica,Arial,sans-serif" width="100%">
                                                            <tbody>
                                                                <tr>
                                                                    <td align="center" width="100%">
                                                                        <h1 style="padding:0;margin:0;color:#ffffff;font-weight:500;font-size:20px;line-height:24px">Email Verification Link</h1>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td align="center" style="padding:20px 0 10px 0">
                                                        <table border="0" cellspacing="0" cellpadding="0" style="font-weight:200;font-family:Helvetica,Arial,sans-serif" width="100%">
                                                            <tbody>
                                                                <tr>
                                                                    <td align="center" width="100%" style="padding: 0 15px;text-align: justify;color: rgb(76, 76, 76);font-size: 12px;line-height: 18px;">
                                                                        <h3 style="font-weight: 600; padding: 0px; margin: 0px; font-size: 16px; line-height: 24px; text-align: center;" class="title-color">Hai. Welcome..! ' .$email.' </h3>
                                                                        <p style="margin: 20px 0 30px 0;font-size: 15px;text-align: center;">Thank you For Registration Please click on Verify Button to <b>Complete Registration</b>!</p>
                                                                        <div style="font-weight: 200; text-align: center; margin: 25px;"><a style="padding:0.6em 1em;border-radius:600px;color:#ffffff;font-size:14px;text-decoration:none;font-weight:bold" class="button-color" href="http://localhost/TASK/user/verify.php?email='.$email.'&verify_code='.$verify_code.'">Verify Now</a>
                        
                                                                        </div>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                                <tr>
                                                </tr>
                                                <tr>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        </td>
                        </tr>
                        <tr>
                        <td align="left">
                        <table bgcolor="#FFFFFF" border="0" cellspacing="0" cellpadding="0" style="padding:0 24px;color:#999999;font-weight:200;font-family:Helvetica,Arial,sans-serif" width="100%">
                            <tbody>
                                <tr>
                                    <td align="center" width="100%">
                                        <table border="0" cellspacing="0" cellpadding="0" style="font-weight:200;font-family:Helvetica,Arial,sans-serif" width="100%">
                                            <tbody>
                                                <tr>
                                                    <td align="center" valign="middle" width="100%" style="border-top:1px solid #d9d9d9;padding:12px 0px 20px 0px;text-align:center;color:#4c4c4c;font-weight:200;font-size:12px;line-height:18px">Regards,
                                                        <br><b>Team TOMWHOCODES</b>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td align="center" width="100%">
                                        <table border="0" cellspacing="0" cellpadding="0" style="font-weight:200;font-family:Helvetica,Arial,sans-serif" width="100%">
                                            <tbody>
                                                <tr>
                                                    <td align="center" style="padding:0 0 8px 0" width="100%"></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        </td>
                        </tr>
                        </tbody>
                        </table>
                        </center>
                        </td>
                        </tr>
                        </tbody>
                        </table>
                        </div>
                        </body>';
                    $mail->isHTML(true); //Set email format to HTML
                    $mail->AltBody = 'click verify to complete the verification process';
                    if($mail->send())
                    {
                        echo '<style type="text/css">#hidediv{
                            display:none;
                            }</style>';
                    
                        echo '
                    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" />
                    <section class="mail-seccess section m-5">
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-6 offset-lg-3 col-12">
                                    <!-- Error Inner -->
                                    <div class="success-inner">
                                        <h1><i class="fa fa-envelope"></i><span> Request Mail Sent Successfully! to <p>'.$_POST['email'].'</p></span></h1>
                                        <p>Click On Verify Now To verify the email</p>
                                        <a href="login.php" class="btn btn-primary btn-lg">Go Home</a>
                                    </div>
                                    <!--/ End Error Inner -->
                                </div>
                            </div>
                        </div>
                    </section>';

                    }else {

                        echo "Mail Sever Error";
                    }



                    return true;
                    }
                    catch (Exception $e) {
                    //echo "Message could not be sent. Mailer Error: { $mail->ErrorInfo }";
                    return false;
                    }
               
                    echo "<h1>Mail Sent Sucessfully</h1>";
                }
                    
                    }//end of mail function
                //     else{

                // echo "Email is Not Deleverable";
                // }
            

    
    if(empty($_POST['email'])){

        echo   "Please Enter Email";
    }
    

        // echo "<h1>Email Send Sucessflly</h1>";
    

?>
