<?php
  require 'function.php';
  global $user;
  global $tid;
  if(isset($_SESSION["id"]))
    {
   $tid = $_SESSION['id'];
   if(isset($_GET['id']))
   {
   global $pid;
   $pid = $_GET['id'];
   $post = mysqli_fetch_assoc($query = mysqli_query($conn, "SELECT * FROM tb_user WHERE id = {$tid}")); 
   
   $a_id = $post['id'];
   $u_id = $_SESSION['id'];  
   if($a_id == $u_id)
   {
      // echo "if authorized authord is requested for edit";
       if(isset($_POST['submit']))
       {

	$img_name = $_FILES['img_upload']['name'];
	$tmp_img_name = $_FILES['img_upload']['tmp_name'];
	$folder = "profile_photos/";
	$ext = explode('.', $img_name);
    $file_name = $ext[0];
    $file_ext = $ext[1];
    $img_url = $folder.$file_name.'_' .time().'.'.$file_ext;
    $author_name = $post['firstname'];
    $author_id =  $post['id']; 
    //move_uploaded_file($tmp_img_name,$folder.$img_name);
    if(isset($_GET['id'])){  
        $id = $_GET['id'];
	if(empty($img_url))
		{
    echo "<script>alert('Please FILL DEATILES')</script>";
    exit;
  }
  
	else { 
         //echo $id;
         $sql = "SELECT * FROM tb_user WHERE (id = '$pid')";
		 $query = mysqli_query($conn,$sql);         
		 if(mysqli_fetch_array($query) > 0)
		 {		 
 
            $img_name = $_FILES['img_upload']['name'];
	        $tmp_img_name = $_FILES['img_upload']['tmp_name'];
	        $folder = "profile_photos/";
			$ext = explode('.', $img_name);
            $file_name = $ext[0];
            $file_ext = $ext[1];
            $img_url = $folder.$file_name.'_' .time().'.'.$file_ext;
            move_uploaded_file($tmp_img_name,$img_url);
			  $sql = "UPDATE tb_user SET profile_img = '$img_url' WHERE id = '$pid'";
			  $query = mysqli_query($conn,$sql);
			  if($query)
			  {
				  //echo "<script> alert('POST updated') </script>"; 
				   header("Location:index.php");
			 
			 }

             else if(0)
             {  
                        echo "<script> alert('POST NOT UPDATED')</script>";
                     }
         }
     }
	 } 
	
}
        //fetch image if exist 
        if(isset($_GET['id']))
        {
        $img_id = $_GET['id'];
        $sql = "SELECT * FROM tb_user WHERE id = {$img_id}";
        $result = mysqli_query($conn,$sql);        
        while ($img_row = mysqli_fetch_array($result))
        {
            $img_url = $img_row['profile_img'];
            $post_name = $img_row['firstname'];
            $email = $img_row['username'];
            $address = $img_row['address'];
            $phone = $img_row['phone'];
             
        }
        }

   }
   
   else if($a_id != $u_id)
   {
   header("Location:unauthorized.php");}
   }

   else if(!(isset($_POST['id']))) {
       
    header("Location:unauthorized.php");

   }

}
    
?>
<!doctype html>
<html lang="en">

<head>
    <title><?php $post_name ?></title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css"
        integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">

</head>

<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-7">
                <div class="card shadow-lg border-0 rounded-lg mt-5">
                    <div class="card-header">
                        <h3 class="text-center font-weight-light my-2"><b class="text-capitalize">UPDATING <?php echo $post_name ." "?> Profile Photo </b></h3>
                    </div>
                    <form action="" method="POST" class="form-group sm-5 m-4" enctype="multipart/form-data">
                        <div class="card " style="width: 100%;">

                            <img class="card-img-top text-capitalize text-center rounded-circle img-fluid" alt=" " style="width:200px; height:200px;" id="output"
                                src="<?php echo $img_url; ?>"
                                title="<?php echo " Review by :". $post_name;?>" />

                            <div class="card-body">
                                <h5 class="card-title">Select Image from Pc</h5>
                                <input type="file" name="img_upload" class="custom-file form-control-file" id="img_upload" accept="image/*" onchange="loadFile(event)" required>
                            </div>
                        </div>
                        <div class="card-body">                       
                            <!-- <input type="hidden" id="post_data" name="post_data" value="post_data" class="form-control"> -->
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <div class="form-floating mb-3 mb-md-0">
                                        <input class="form-control text-capitalize" id="name" name="author_name"
                                            type="text" value="<?php echo $post_name; ?>" disabled />
                                        <label for="author">Name</label>
                                    </div>
                                    
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating mb-3 mb-md-0">
                                        <input class="form-control" id="username" name="author_name"
                                            type="text" value="<?php echo $email; ?>" disabled />
                                        <label for="author">Author</label>
                                    </div>
                                    
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating">

                                        <input class="form-control text-uppercase" id="title" name="title" type="text" value="<?php echo $phone ?>" disabled/>
                                        <label for="title" class="form-lable text-capitalize">Contact
                                            </label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating">

                                        <input class="form-control text-uppercase" id="title" name="title" type="text" value="<?php echo $address ?>" disabled/>
                                        <label for="title" class="form-lable text-capitalize">Location</label>
                                    </div>
                                </div>
                            </div>

                            <div class="form-floating mb-3">
                                <!-- <input class="form-control" id="img_url" name="img_url" type="text"required /> -->
                            </div>
                        </div>
                       
                                <div class="mt-4 mb-0">
                                    <div class="d-grid mb-2">
                                        <input type="hidden" id="action" value="addpost" class='form-control'>
                                        <input type="submit" class="btn btn-md btn-primary btn-block form-control"
                                            onclick="" id='submit' value="Update" name='submit' />
                                    </div>
                                </div>
                    </form>
                    </div>

</body>
<script>
var loadFile = function(event) {
    var output = document.getElementById('output');
    output.src = URL.createObjectURL(event.target.files[0]);
    output.onload = function() {
        URL.revokeObjectURL(output.src);
    }
};
</script>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
    integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
    integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous">
</script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
    integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous">
</script>

</html>