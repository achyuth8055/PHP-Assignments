<?php

 $conn = mysqli_connect("localhost","root","","testing");

 if(!$conn){echo "connection failed";}

  $post = "Hellow Post";
  $email = 'achyuthkumark2000@gmail.com';
  $author_id = '1';
  $sql = "SELECT * FROM subs ";
  $query = mysqli_query($conn,$sql);

  while($subs = mysqli_fetch_array($query))
  {

    $pa_id = $subs['author_id'];
    $nemail = $subs['email'];

    if($subs['email'] > 0 )
    {
       
    
        if($nemail == $email)
        {
        echo "email exist already checking the author id";
               echo $pa_id.$nemail;
               echo $email.$author_id;
               
            if($author_id == $pa_id)
            {
                echo '<script> alert("already a subscriber")</script>';
                echo "<h1> Already a subscriber</h1>";
                die();
            
            
            }
        }
            else{

                echo "<h1>Insert Email And New Author id</h1>";
                die();
            }
    }
    else {

        echo '<script>alert("inserting an new subscriber")</script>';
                echo "<h1>inserting an new subscriber</h1>";
                die();
    }
}

?>
<h1>subscribers </h1>