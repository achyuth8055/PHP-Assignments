
function submitEdit() {
    $(document).ready(function() {
        var data = {
            action: $("#action").val(),

			img_url: $("#img_url").val(),
            profile_img: $('#profile_img').val(),
			textcontent: $("#textcontent").val(),
			author: $("#author").val(),
			title: $("#title").val(),	
            // edit data
        };

        $.ajax({
            url: 'test2.php',
            type: 'post',
            data: data,
            success: function(response) {
                console.log(response);
                console.log(data);
                swal({
                    type: "success",
                    title: "Alert Message",
                    text: response,                 
                   
                    
                }).then(function()
                 {    
                    console.log(response);  
                });
            }
        });

   


    });

}