<?php
require 'function.php';
global $user;

if(isset($_SESSION["id"]))
{
  $id = $_SESSION["id"];
  
  $author = mysqli_fetch_assoc($query = mysqli_query($conn, "SELECT * FROM tb_user WHERE id = $id"));          
}
else{
  header("Location: login.php");
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="utf-8">
    <title>Home</title>
</head>

<body>

</body>

</html>

<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Dashboard</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
		 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.1/css/all.min.css" integrity="sha256-2XFplPlrFClt0bIdPgpz8H7ojnk10H69xRqd9+uTShA=" crossorigin="anonymous" />
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
        
        <style type="text/css">
		body {
             font-family: arial;
             }
            .hide{
			display: none;
				}
		
		</style>
    </head>
    <body class="sb-nav-fixed">
        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <!-- Navbar Brand-->
            <a class="navbar-brand ps-3" href="index.php">Home</a>
            <!-- Sidebar Toggle-->
            <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
            <!-- Navbar Search-->
            <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
                <div class="input-group">
                    </div>
            </form>
            <!-- Navbar-->
            <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="profile.php"><b><?php echo $author["firstname"];?></b></a></li>
                        <li><a class="dropdown-item" href="#!"></a></li>
                        <li><hr class="dropdown-divider" /></li>
                        <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <div class="sb-sidenav-menu-heading text-center">Profile Photo</div>
                            <a class="nav-link text-capitalize" href="profile.php">
                                <div class="sb-nav-link-icon text-light text-center ">
                                    <img src="<?php echo $author['profile_img']?>" alt="profile_photo" class="rounded-circle m-4" height="100px" width="100px"/><!--<i class="as fa-user"></i>-->
                                <p><?php echo "<h5>".$author['firstname']."</h5>"; if($author['account_state']=='1'){ echo '<i class="fas fa-check-circle" title="verified">'; }else{ echo '<i class="fa-solid fa-ban" title="not A verified Account"></i>';} ?></i></p>
                                </div>
                        
                            </a>                            
                            <div class="collapse" id="collapsePages" aria-labelledby="headingTwo" data-bs-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav accordion" id="sidenavAccordionPages">
                                    </nav>
                            </div>
                            <div class="sb-sidenav-menu-heading">Post Related</div>
                            <a class="nav-link" href="post/home.php">
                                <div class="sb-nav-link-icon"><i class="fa-solid fa-file"></i></div>
                                View all Post
                            </a>
                            <a class="nav-link" href="addpost.php">
                                <div class="sb-nav-link-icon"><i class="fa-solid fa-file-text" aria-hidden="true"></i></div>
                                Create New
                            </a>                            
                        </div>
                    </div>
                    <div class="sb-sidenav-footer">
                        <div class="small text-capitalize">Loggedin as: <?php echo $author["firstname"];echo " ";echo $author['lastname']?></div>
                        
                    </div>
                    
                </nav>
            </div>
            <!--content hre to -->

<div class="container w-100  d-flex justify-content-end">
<div class="col-lg-9 mt-4 mt-lg-0">
    <div class="row">
      <div class="col-md-12">
        <div class="user-dashboard-info-box table-responsive mb-0 bg-white p-4 shadow-sm">
          <table class="table manage-candidates-top mb-0">
            <thead>
              <tr>
                <th class="text-capitalize text-center">All Author names Name</th>
                <th class="text-center text-capitalize">username ID</th>
                <!-- <th class="action text-right">Action</th> -->
              </tr>
            </thead>
            <tbody>
                <?php 
                $query = mysqli_query($conn, "SELECT * FROM tb_user");
                while($row = mysqli_fetch_assoc($query))
                {
                      
                ?>
              <tr class="candidates-list ">
                <td class="title">
                  <div class="thumb">
                    <img class="rounded-circle" src="<?php echo $row['profile_img']?>" alt="" style="height:100px;width:100px;">
                  </div>
                  <div class="candidate-list-details ">
                    <div class="candidate-list-info">
                      <div class="candidate-list-title">
                        <h5 class="mb-0 text-capitalize"><a style="text-decoration: none;" class="text-dark px-4 py-4"href="user_profile.php?id=<?php echo $row['id'];?>"><?php echo $row['firstname']?></a></h5>
                      </div>
                      <div class="candidate-list-option col float-end">
                        <ul class="list-unstyled">
                          <li><i class="fas fa-filter pr-1"></i><?php echo $row['role']?></li>
                          <li><i class="fas fa-map-marker-alt pr-1 text-capitalize"></i><?php echo $row['address']?></li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </td>
                <td class="candidate-list-favourite-time text-center">
                  <a class=" candidate-list-favourite order-2 text-dark row" href=""><i class="fas fa-user"></i></a>
                  <span class="candidate-list-time order-1 "><?php echo $row['username']?></span>
                </td>              
              </tr>
           <?php
            }
            $count = 0;
            while($row1 = mysqli_fetch_assoc($query))
            {
                $count = $row1['id'] + $count; 
                
           
                ?>
            </tbody>
          </table>
          <div class="text-center mt-3 mt-sm-3">
            <ul class="pagination justify-content-center mb-0">
              <li class="page-item disabled"> <span class="page-link">Prev</span> </li>
              <li class="page-item active" aria-current="page"><span class="page-link">1 </span> <span class="sr-only">(current)</span></li>
              <li class="page-item"><a class="page-link" href="?id=<?php echo $row['id'];?>"> <?php echo $count ?></a></li>
              <!-- <li class="page-item"><a class="page-link" href="?id=<?php echo $row['id'];?>">3</a></li> -->

            </ul>
            <?php
            }
            ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>


            <!--to here  -->
        </div>
 
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
  
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    </body>
</html>
