function cancel()
{
 //hide_IMG_URL
  document.getElementById('hide_firstname').style.display = 'none';
  document.getElementById('hide_username').style.display = 'none';
  document.getElementById('hide_phone').style.display = 'none';
  document.getElementById('hide_address').style.display = 'none';
  document.getElementById('hide_btn').style.display = 'none';
  document.getElementById('update').style.display = 'none';
  document.getElementById('edit_button').style.display = 'block';
}
function edit()
{
  document.getElementById('hide_firstname').style.display = 'block';
  document.getElementById('hide_username').style.display = 'block';
  document.getElementById('hide_phone').style.display = 'block';
  document.getElementById('hide_address').style.display = 'block';
  document.getElementById('hide_btn').style.display = 'block';
  document.getElementById('update').style.display = 'block';
  document.getElementById('edit_button').style.display = 'none';
}



