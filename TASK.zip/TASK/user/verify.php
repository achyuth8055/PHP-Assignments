<?php
include("function.php");
global $verify_code;

if(isset($_GET['email']) && isset($_SESSION['verify_code'])){



      $email = $_GET['email'];
      $code = $_SESSION['verify_code'];
      $verify = $_SESSION['verify_code'];
      $sql = "SELECT * FROM tb_user WHERE username = '$email' ";
      $query = mysqli_query($conn,$sql);
      if(!isset($query))
      {
        exit;
        echo "Done";
      }
      while($row = mysqli_fetch_assoc($query))
       {
            
            $status = $row['account_state'];
  
            if($status == 1)
            {
                echo '<!DOCTYPE html>
                <html lang="en">
                    <head>
                        <meta charset="utf-8" />
                        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
                        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
                        <meta name="description" content="" />
                        <meta name="author" content="" />
                        <title>Verified</title>
                        <link href="css/styles.css" rel="stylesheet" />
                        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
                    </head>
                    <body>
                        <div id="layoutError">
                            <div id="layoutError_content">
                                <main>
                                    <div class="container">
                                        <div class="row justify-content-center">
                                            <div class="col-lg-6">
                                                <div class="text-center mt-4">
                                                    <h1 class="display-1">401</h1>
                                                    <p class="lead">Unauthorized</p>
                                                    <p>This Mail Already Verfied</p>
                                                    <a href="index.php">
                                                        <i class="fas fa-arrow-left me-1"></i>
                                                        Return to Dashboard
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </main>
                            </div>
                            <div id="layoutError_footer">
                                <footer class="py-4 bg-light mt-auto">
                                    <div class="container-fluid px-4">
                                        <div class="d-flex align-items-center justify-content-between small">
                                            <div class="text-muted">Copyright &copy; Your Website 2022</div>
                                            <div>
                                                <a href="#">Privacy Policy</a>
                                                &middot;
                                                <a href="#">Terms &amp; Conditions</a>
                                            </div>
                                        </div>
                                    </div>
                                </footer>
                            </div>
                        </div>
                        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
                        <script src="js/scripts.js"></script>
                    </body>
                </html>
                ';
            }
  
            if($code == $verify && $status == '0')
            {
  
              unset($_SESSION['verify_code']);
              $sql1 = "UPDATE tb_user SET account_state = '1' WHERE username = '$email'";
              $query = mysqli_query($conn,$sql1);
  
              if($query){
  
                  echo '<html>
                  <head>
                    <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:400,400i,700,900&display=swap" rel="stylesheet">
                  </head>
                    <style>
                      body {
                        text-align: center;
                        padding: 40px 0;
                        background: #EBF0F5;
                      }
                        h1 {
                          color: #88B04B;
                          font-family: "Nunito Sans", "Helvetica Neue", sans-serif;
                          font-weight: 900;
                          font-size: 40px;
                          margin-bottom: 10px;
                        }
                        p {
                          color: #404F5E;
                          font-family: "Nunito Sans", "Helvetica Neue", sans-serif;
                          font-size:20px;
                          margin: 0;
                        }
                      i {
                        color: #9ABC66;
                        font-size: 100px;
                        line-height: 200px;
                        margin-left:-15px;
                      }
                      .card {
                        background: white;
                        padding: 60px;
                        border-radius: 4px;
                        box-shadow: 0 2px 3px #C8D0D8;
                        display: inline-block;
                        margin: 0 auto;
                      }
                    </style>
                    <body>
                      <div class="card">
                      <div style="border-radius:200px; height:200px; width:200px; background: #F8FAF5; margin:0 auto;">
                        <i class="checkmark">✓</i>
                      </div>
                        <h1>Success</h1> 
                        <p>Email Verfication;<br/> sucessful!</p>
                        <a href="index.php">Dashboard</p>
                      </div>
                    </body>
                </html>';
  
              }
  
            }
      }
  
  
     }
  
    




?>