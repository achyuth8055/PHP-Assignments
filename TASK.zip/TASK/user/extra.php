<?php


echo '
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Blog Post</title>
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <link href="css/styles.css" rel="stylesheet" />
        <script src="../script.js"></script>
        <script src=""></script>
    </head>';
    echo '<body>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <div class="container">
                <a class="navbar-brand" href="../login.php">HOME</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                        <!--<li class="nav-item"><a class="nav-link" href="#">Home</a></li>
                        <li class="nav-item"><a class="nav-link" href="#!">About</a></li>
                        <li class="nav-item"><a class="nav-link" href="#!">Contact</a></li>-->
                        <li class="nav-item"><a class="btn btn-outline-light" aria-current="page" href="viewall">View all posts</a></li>
                    </ul>
                </div>
            </div>
        </nav>';

$server = "localhost";
$user = "root";
$pasd= "";
$db = "testing";
$con = mysqli_connect($server,$user,$pasd,$db);
$sql = "SELECT * FROM post WHERE id='$id'";
$result = mysqli_query($con, $sql);
 
if($result)
 {
    if(mysqli_num_rows($result) > 0)
     {
         while($row = mysqli_fetch_assoc($result)){             
        echo'<div class="container mt-5">
            <div class="row">
                <div class="col-lg-8">
                    <article>
                        <header class="mb-4">';
                            echo'<h1 class="fw-bolder mb-1 text-center">'.$row['title'].'</h1>';
                            echo'<div class="text-muted fst-italic mb-2">';
                            echo" <p> Posted on ".$row['timestamp']." by  </p>";
                            $img = $row['img'];
                        echo'</div>
                           </header>
                        
                        <figure class="mb-4"><img class="img-fluid rounded" src="'.$img.'" alt="post_image" width="600px"/></figure>
                        
                        <section class="mb-5">
                            <p class="fs-5 mb-4">'.$row["textcontent"].'</p>
                            </section>
                    </article>';
              
    echo '<footer class="py-5 bg-dark">
            <div class="container"><p class="m-0 text-center text-white">Copyright &copy; Your Website 2022</p></div>
        </footer>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="js/scripts.js"></script>
    </body>
</html>';
}
mysqli_free_result($result);
}
}
?>