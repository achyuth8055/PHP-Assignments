<?php
require 'function.php';
global $user;
if(isset($_SESSION["id"]))
{
  $id = $_SESSION["id"];
  $user = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM tb_user WHERE id = $id"));          
}
else{
  header("Location: login.php");
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="utf-8">
    <title>Profile</title>
</head>
<body>
</body>
</html>
<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <style>
    body {
        font-family: arial;
    }

    .hide {
        display: none;
    }
    
    </style>
</head>
<body >
    <nav class="navbar navbar-expand-sm sticky-top navbar-dark bg-dark" id="navbar">
        <a class="navbar-brand text-capitalize text-light" href=""> Welcome <strong>
                <?php  echo $user["firstname"]; echo " ";echo $user['lastname']; ?></strong></a> 
        <button class="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#collapsibleNavId"
            aria-controls="collapsibleNavId" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="collapsibleNavId">

            <form class="form-inline my-2 my-lg-0">
                <span class='float-right'>
                    <a class="btn btn-outline-dark my-2 my-sm-0 text-light" type="submit" href='logout.php'>Logout</a>
                </span>
            </form>
        </div>
        <div class=" float-md-right">
            <form class="form-inline ml-4" >

                <a class="btn btn-outline-dark my-2 my-sm-0 text-capitalize text-light" onclick="edit();" href="#">edit my
                    data</a>
                &nbsp;
                <div class='hide' id="hide_btn">
                    <button class="btn btn-dark col-xs-2" onclick="cancel();"> Cancel Edit </button>
                </div>
            </form>
        </div>
    </nav>
    <!--dummy-->
<!-- <nav class="navbar navbar-expand-sm sticky-top navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="#">Brand</a>
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbar1">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbar1">
            <ul class="navbar-nav">
                <li class="nav-item active">
                    <a class="nav-link" href="#">Link</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Link</a>
                </li>
            </ul>
            <ul class="navbar-nav ml-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="#">Link</a>
                </li>
            </ul>
        </div>
    </div>
</nav> -->
<!--dummy-->
    <section style="background-color: #eee;">
        <div class="container py-3">
            <div class="row">
                <div class="col">
                    <nav aria-label="breadcrumb" class="bg-light rounded-3 p-3 mb-4 text-dark">
                        <ol class="breadcrumb mb-0 ">
                            <li class="breadcrumb-item "><a href="index.php" class="text-dark">Home</a></li>
                            <li class="breadcrumb-item "><a href="allusers.php" class=" text-dark">User</a></li> 
                            <li class="breadcrumb-item active text-capitalize text-danger" aria-current="page">
                                <?php echo $user["firstname"]?></li>
                        </ol>
                    </nav>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4">
                <form method="post" enctype="multipart/form-data">
                    <div class="card mb-4">
                        <div class="card-body text-center"> 
                        <img src="<?php echo $user["profile_img"];?>" alt="User Profile" id="img" style="width:200px; height:200px;" class="rounded-circle img-fluid">
                        <h5 class="my-3 text-capitalize"><?php echo $user['firstname']; if($user['account_state']== 1){ echo ' <i class="fas fa-check-circle ml-1 text-capitalize" title="verified user"> '; }else{ echo '<i class="fa-solid fa-ban ml-1 text-capitalize" title="Required Email Verfication"></i>';} ?></i></h5>
                        <a href="edit_photo.php?id=<?php echo $user["id"]; ?>" class="btn btn-outline-dark text-capitalize" >update Profile Photo</a>
                        <?php if($user['account_state'] == 0) {  
                            
                          $verify_code = bin2hex(random_bytes(16));
                     ?>
                        <a href="req_verify.php?email=<?php echo $user["username"]."&verify_code=".$verify_code; ?>" class="btn btn-primary btn-sm-4 m-1 text-capitalize" >Send Verfication Mail</a>
                        <?php  } ?>                       
                        </div>         
                    </div>
                
                </form>
                </div>
                <div class="col-lg-8">
                    <div class="card mb-4">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-sm-3">
                                    <p class="mb-0">Full Name</p>
                                </div>
                                <div class="col-sm-9">
                                    <b>
                                        <p class="text-dark mb-0 text-capitalize"><?php echo $user["firstname"];?></p>
                                        <div id="hide_firstname" class="hide col-xs-2 " name="hide">
                                            <input class="form-control text-capitalize" type="text" value="<?php echo $user['firstname']?>" name="firstname" id="firstname">
                                            &nbsp;
                                        </div>
                                    </b>
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-sm-3">
                                    <p class="mb-0">Email</p>
                                </div>
                                <div class="col-sm-9">
                                    <b>
                                        <p class="text-dark mb-0"><?php echo $user["username"];?></p> </b>
                                        <div id="hide_username" class="hide col-xs-2" name="hide">
                                             <input class="form-control " type="hidden"
                                                value="<?php echo $user['username']?>" name="hide_username"
                                                id="username"> 
                                           
                                        </div>
                                   
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-sm-3">
                                    <p class="mb-0">Phone</p>
                                </div>
                                <div class="col-sm-9">
                                    <b>
                                        <p class="text-dark mb-0"><?php echo $user["phone"];?></p>
                                        <div id="hide_phone" class="hide col-xs-2" name="hide">
                                            <input class="form-control" type="text" value="<?php echo $user['phone']?>"
                                                name="hide_phone" id="phone">
                                            &nbsp;
                                        </div>
                                    </b>
                                </div>
                            </div>
                            <hr>

                            <div class="row">
                                <div class="col-sm-3">
                                    <p class="mb-0">Address</p>
                                </div>
                                <div class="col-sm-9">
                                    <b>
                                        <p class="text-dark mb-0 text-capitalize"><?php echo $user["address"];?></p>
                                        <div id="hide_address" class="hide col-xs-2" name="hide" class="form-group">
                                            <input type="hidden" id="action" name='action' value="update"
                                                class="form-control ">
                                            <input class="form-control text-capitalize" type="text"
                                                value="<?php echo $user['address']?>" name="hide_address" id="address">
                                            &nbsp;
                                            <br>
                                            <button id="update" type="submit" class="btn btn-outline-dark hide hide_update text-uppercase"
                                                name='update_btn' onclick="submitData();">update</button>
                                        </div>
                                    </b>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="card mb-4 mb-md-0">
                                <div class="card-body ">
                                    <p class="mb-4"><span class="text-dark font-italic me-1 text-capitalize"></span>
                                    </p>
                                    <a href="home.php" class="btn btn-outline-dark" id="create" name="create">view
                                        Dashboard</a>
                                        <a href="index.php" class="btn btn-outline-dark" id="create" name="create">view
                                        Home</a>
                                    <!-- <p class="mb-1" style="font-size: .77rem;">Front End Design</p> -->
                                    <!-- <div class="progress rounded" style="height: 5px;">
                                        <div class="progress-bar" role="progressbar" style="width: 80%"
                                            aria-valuenow="80" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div> -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <div class="footer text-center py-2 bg-light">
     <a href="#home" class="text-center text-dark" style="text-decoration: none;"><b>Copyright ©2022 TOM, CMS-Project ® </b></a>
    </div>
    <script>
  function readURL(input) {
    if (input.files && input.files[0]) 
    {    
      var reader = new FileReader();
      reader.onload = function (e) { 
        document.querySelector("#img").setAttribute("src",e.target.result);
      };

      reader.readAsDataURL(input.files[0]); 
    }
  }
  </script>
<script src="script.js"></script>
<script src="img/hide.js"></script>
</body>

<!-- profile ending -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
    integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
    integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous">
</script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
    integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous">
</script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js">
</script>




</html>