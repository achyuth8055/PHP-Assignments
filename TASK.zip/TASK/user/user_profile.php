<?php
require 'function.php';
global $user_id;
global $user;
//$user = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM tb_user"));

if(isset($_SESSION["id"]))
{
  $id = $_SESSION["id"];

  if(isset($_GET['id']))
   {
    $user_id = $_GET['id'];
    $author = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM tb_user WHERE id = $id"));
    if($_SESSION['id'] != $author['id'])
    {
        header("Location:error.php");
    }
    if(!isset($author['id']))
    {
      header("Location:error.php");
    }
    if(empty($_GET['id']))
    {
        echo "<script>alert('no parameter');</script>";
        die();
    }

}
else if(!isset($_GET['id']))
{
  header("Location:error.php");
}
  
}

else{
  echo "<h2>login to open author profile</h2>";
  echo '<a href="login.php" >Click me To login</a>';
  die();
  //header("Location: login.php");
}

?>
<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="utf-8">
    <title>Home</title>
</head>

<body>

</body>

</html>

<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>User-Profile</title>
        <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
       <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
		 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.1/css/all.min.css" integrity="sha256-2XFplPlrFClt0bIdPgpz8H7ojnk10H69xRqd9+uTShA=" crossorigin="anonymous" />
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
        
        <style type="text/css">
		body {
             font-family: arial;
             }
            .hide{
			display: none;
				}
		
              
        .gradient-custom {
        background: #615e56;
        background: -webkit-linear-gradient(to right bottom, rgba(48, 48, 48, 1), rgba(48, 48, 48, 1));
        background: linear-gradient(to right bottom, rgba(48, 48, 48, 1), rgba(48, 48, 48, 1))
        }
  
		</style>
    </head>
    <body class="sb-nav-fixed">

        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <!-- Navbar Brand-->
            <a class="navbar-brand ps-3" href="index.php">Home</a>
            <!-- Sidebar Toggle-->
            <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
            <!-- Navbar Search-->
            <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
                <div class="input-group">
                    </div>
            </form>
            <!-- Navbar-->
            <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="profile.php"><b><?php echo $author["firstname"];?></b></a></li>
                        <li><a class="dropdown-item" href="#!"></a></li>
                        <li><hr class="dropdown-divider" /></li>
                        <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <div class="sb-sidenav-menu-heading">Profile Photo</div>
                            <a class="nav-link text-capitalize" href="profile.php">
                                <div class="sb-nav-link-icon text-light text-center">
                                    <img src="<?php echo $author['profile_img']?>" alt="profile_photo" class="rounded-circle" width="100px" height="100px"/><!--<i class="as fa-user"></i>-->
                                <p><?php echo "<h5>".$author['firstname']."</h5>"; if($author['account_state']=='1'){ echo '<i class="fas fa-check-circle" title="verified">'; }else{ echo '<i class="fa-solid fa-ban" title="not A verified Account"></i>';} ?></i></p>
                                </div>
                        
                            </a>                            
                            <div class="collapse" id="collapsePages" aria-labelledby="headingTwo" data-bs-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav accordion" id="sidenavAccordionPages">
                                    </nav>
                            </div>
                            <div class="sb-sidenav-menu-heading">Post Related</div>
                            <a class="nav-link" href="post/home.php">
                                <div class="sb-nav-link-icon"><i class="fa-solid fa-file"></i></div>
                                View all Post
                            </a>
                            <a class="nav-link" href="addpost.php">
                                <div class="sb-nav-link-icon"><i class="fa-solid fa-file-text" aria-hidden="true"></i></div>
                                Create New
                            </a>                            
                        </div>
                    </div>
                    <div class="sb-sidenav-footer">
                        <div class="small text-capitalize">Loggedin as: <?php echo $author["firstname"];echo " ";echo $author['lastname']?></div>
                        
                    </div>
                    
                </nav>
            </div>
            <!--content hre to -->

           <div class="mt-5"></div>
    <div class="col d-flex justify-content-center  h-100 mt-5 pt-5">
      <div class="row col-lg-6 ">
          <?php
global $conn;                                        
$jsql = "SELECT * FROM  tb_user WHERE id = '$user_id' ";                                      
$result = mysqli_query($conn,$jsql);
while($row = mysqli_fetch_assoc($result)){
$img = $row['profile_img'];
?>
        <div class="card mb-3" style="border-radius: .5rem;">
          <div class="row g-0">
            <div class="col-md-4 gradient-custom text-center text-white"
              style="border-top-left-radius: .5rem; border-bottom-left-radius: .5rem;">
              <img src="../user/<?php echo $img ?>"
                alt="avatar" class="img-fluid my-5 rounded-circle" style="width: 120px; height:120px;" title="<?php echo " Profile Photo Of : ".$row['firstname'];?>"/>
               
                <h5 class="text-uppercase"><?php echo $row['firstname']?></h5>
              <p class="text-capitalize"><?php echo $row['role']?></p>
             
            </div>
            <div class="col-md-8">
              <div class="card-body p-4">
                <h6 class="text-uppercase">User Information</h6>
                <hr class="mt-0 mb-4">
                <div class="row pt-1">
                  <div class="col-6 mb-3 p-2">
                    <h6>Email</h6>
                    <p class="text-muted "><?php echo $row['username']?></p>
                  </div>
                  <div class="col-6 mb-3">
                    <h6>Phone</h6>
                    <p class="text-muted"><?php echo $row['phone']?></p>
                  </div>
                </div><?php } ?><?php ?>
                
                
                <h6>Number of Post Uploaded</h6>
                <hr class="mt-0 mb-4">
                <div class="row pt-1">
                <?php
               global $conn;
                                                       
               $sql = "SELECT * FROM  post WHERE author_id = '$user_id' ";                                      
               $res = mysqli_query($conn,$sql);
               $count = 0;
               while($row_post = mysqli_fetch_assoc($res)){
               
                $count++;
                $recent_post = $row_post['title'];
              }
               ?>
                  <div class="col-6 mb-3">
                    <h6>Recent Review</h6>
                    <p class="text-muted" maxlength="25"><?php if(!isset($recent_post)){echo "No Post Uploaded";} else echo $recent_post ?></p>
                  </div>
                  <div class="col-6 mb-3">
                    <h6>Total Post Count</h6>
                    <p class="text-muted"><?php echo $count ?></p>
                  </div>
                </div>
               
                <div class="d-flex justify-content-start">
                  <a href="https://www.facebook.com/" class="text-primary text-capitalize p-2" style="text-decoration: none;">Facebook</a>
                  <a href="https://www.twitter.com/" class="text-primary text-capitalize p-2" style="text-decoration: none;">twitter</a>
                  <a href="https://www.instagram.com/" class="text-primary text-capitalize p-2" style="text-decoration: none;"> instagram</a>
                </div>
                <a type="button" href="allusers.php" class="btn gradient-custom text-capitalize mt-1 text-light"><i class="fa fa-arrow-left" aria-hidden="true"></i> click to back</a>
              </div>
            </div>
          </div>
          <?php  ?>

        </div>
      </div>
    </div>
         <!--to here  -->
        </div>
 
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
  
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script></body>
</html>
