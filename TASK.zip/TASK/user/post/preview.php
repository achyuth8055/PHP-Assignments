<?php
require '../function.php';
//require '../required.php';
if($_GET['id']==""){
    echo "login";
    header("Location:../unauthorized.php");
 }

if(!isset($_SESSION["id"]))
{
//   $id = $_SESSION["id"];
//   $user = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM tb_user  WHERE id = $id"));
  if(isset($_GET['id']))
  {
    $Pid = $_GET['id'];
    $row = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM post  WHERE id = $Pid"));
  }
  
  if(!isset($_GET['id']))
 {
    // echo "shift unauthorized !get id";
   header("Location:../unauthorized.php");
 }

}
// if sucessful login
if(isset($_SESSION["id"]))
{
  $id = $_SESSION["id"];
  $user = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM tb_user  WHERE id = $id"));
  if(isset($_GET['id']))
  {
    $Pid = $_GET['id'];
    $row = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM post  WHERE id = $Pid"));
  }
  
  if(!isset($_GET['id']))
 {
    // echo "shift unauthorized !get id";
   header("Location:../unauthorized.php");
 }

}
 else if(!isset($row['id']))
{
 //echo "shift unauthorized rowid";
header("Location:../unauthorized.php");
}

?>

<!doctype html>
<html lang="en">

<head>
    <title>Preview</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
   
</head>

<body class="bg-light">

<nav class ="navbar navbar-expand-lg sticky-top  navbar-dark bg-dark">
<a class ="navbar-brand text-light" href ="../index.php"> HOME </a>
<button class ="navbar-toggler" type ="button" data-toggle ="collapse" data-target ="#colNav">
<span class ="navbar-toggler-icon"></span>
</button>
<div class ="collapse navbar-collapse" id ="colNav">
<ul class ="navbar-nav navbar-right">
    <?php if(!isset($_SESSION['id'])){ ?>
<li class ="nav-item">
<a class ="nav-link text-light h5" href="../login.php"><span class="fa fa-sign-in fa-sm text-light "></span> Login </a>
</li>
<li class ="nav-item">
<a class ="nav-link text-light h5" href ="../register.php"><span class="fa fa-user-plus fa-sm text-light "></span> Sign Up</a>
</li>
<?php } else{ echo '
  <div class="btn-group py-4 mr-3">
  <button type="button" class="btn btn-dark dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
  <a class="dropdown-item text-light text-uppercase bg-dark" href="">'.$user["firstname"].'</a>
  </button>
  <div class="dropdown-menu">
    
  <a class="dropdown-item" href="../profile.php">My Profile</a> 
  <a class="dropdown-item text-capitalize" href="../user_profile.php?id='.$row["author_id"].'">open author profile</a>
    <a class="dropdown-item" href="../index.php">View All Post</a>
    
    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="../logout.php">Logout</a>
  </div>
</div>
'; } ?>
<li class ="nav-item">
<a class ="nav-link text-light h5" href ="../index.php"><span class="fa fa-globe fa-sm text-light"></span> View All </a>
</li>
</ul>
</div>
</nav>

<!-- 
      <nav class="navbar navbar-expand-sm sticky-top navbar-dark bg-dark">
        <div class="container-fluid">
            <button class="navbar-toggler ps-0" type="button" data-mdb-toggle="collapse"
                data-mdb-target="#navbarExample01" aria-controls="navbarExample01" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon d-flex justify-content-start align-items-center">
                    <i class="fas fa-bars"></i>
                </span>
            </button>
            <div class="collapse navbar-collapse" id="navbarExample01">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item active">
                        <a class="nav-link text-light" aria-current="page" href="../index.php"><span class="h3">Home</span></a>
                    </li>
                </ul>
            </div>
        </div>
    </nav> -->

    <!--navbar ending-->
    <div class="container d-md-flex align-items-stretch mt-5">
        <!-- Page Content  -->
        <div id="content" class="p-4 p-md-5 pt-5">
            <p class="text-capitalize m-1"><span class="h1 text-uppercase"><?php echo $row['title']; ?></span> <br>posted
                by <?php echo $row['author']; " on "; echo $row['timestamp']; ?></p>
            <div>
                <!--coment-->
                <form action="" method="get">
                    <article>
                        <header class="mb-4">
                            <figure class="mb-4 align-center px-5 ml-5"><img class="img-fluid rounded m-1 " src="../<?php echo $row['img'];?> "
                                    alt="post_image" width="450px" height="25px" title="<?php echo $row['author']."'s Post"?>" />
                            </figure>
                            <section class="mb-5">
                                <p class="fs-5 mb-4"><?php echo $row["textcontent"]; ?>
                                </p>
                            </section>
                    </article>
                </form>
                <!--coment-->
                </p>
            </div>
        </div>
        <nav id="sidebar" class='mt-5'>
            <div class="p-4 pt-5">
                <h3 class="text-dark text-capitalize ">Author Information <?php  $id1 = $_GET['aid']; 
                $user1 = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM tb_user  WHERE id = $id1")); 
                
                if($user1['account_state']==1){ echo '<i class="fa fa-check-circle" title="Verified Author"></i>'; }else{ echo '<i class="fa fa-times" title="Author Not Verified"></i>';} ?></h5>
                <ul class="list-unstyled components mb-5">
                    <li>
                        <a href="#pageSubmenu1" data-toggle="collapse" aria-expanded="false"
                            class="dropdown-toggle">Authors</a>
                        <ul class="collapse list-unstyled" id="pageSubmenu1">

                            <?php 
                
                $jsql = "SELECT * FROM tb_user";
$result = mysqli_query($conn, $jsql);
 
if($result)
 {
    if(mysqli_num_rows($result) > 0)
     {
         while($row = mysqli_fetch_assoc($result)){ 
                ?>
                            <li><a class="text-capitalize" href="../user_profile.php?id=<?php echo $row['id']; ?>">
                                    <span class="mr-2"></span> <?php echo $row['firstname'];?></a></li>

                            <?php 
                }
            
        ?>
                        </ul>
                    </li>
                    <li>
                        <a href="#pageSubmenu2" data-toggle="collapse" aria-expanded="false"
                            class="dropdown-toggle">Author Posts</a>
                        <ul class="collapse list-unstyled" id="pageSubmenu2">
                            <?php  
                            $aid = $_GET["aid"];
                     $jsql = "SELECT * FROM post WHERE author_id = $aid";
                     $result = mysqli_query($conn, $jsql);
                    while($row = mysqli_fetch_assoc($result)){ 
                ?>
                            <li><a href="preview.php?id=<?php echo $row['id'].'&aid='.$aid;?>" class="text-capitalize"><span
                                        class="text-capitalize"></span> <?php echo $row['title'];?></a></li>

                            <?php 
                }
            }
        }
        ?>
                        </ul>
                    </li>
                </ul>
                <?php 
                if(isset($_SESSION['id']))
                {
                    if($_SESSION['id'] == $_GET['aid']){
                
                ?>
                <div class="mb-4 ">
                    <h4 class="text-dark text-capitalize">Edit This Post</h4>
                    <div class="col">
                        <a type="submit" href="../edit.php?id=<?php echo $_GET["id"]?>" class="text-light btn btn-outline-dark p-3 form-control">Edit Post</a>
                    </div>
                </div>
                <?php }}?>
                <div class="mb-5">
                    <h5 class="text-dark">TAGS</h5>
                    <div class="tagcloud">
                        <a href="" class="tag-cloud-link btn btn-outline-dark">Tech</a>
                        <a href="" class="tag-cloud-link btn btn-outline-dark">Finance</a>
                    </div>
                </div>
                
                <div class="mb-5">
                    <h5 class="text-dark">Subscribe For More</h5>
                    <form action="../req_verify.php" method="post" class="subscribe-form">
                        <div class="form-group d-flex">
                            <div class="icon"><span class="icon-paper-plane"></span></div>
                            <input type="text" class="form-control" placeholder="Enter Email Address" name="email"
                                autocomplete="off">
                            <input type="submit" name="submit" class="form-control">
                        </div>
                    </form>
                </div>
            </div>
        </nav>
    </div>
    <script src="js/jquery.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
</body>

</html>