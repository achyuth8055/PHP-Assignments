<?php
require 'function.php';


if(isset($_SESSION["id"]))
{
  $id = $_SESSION["id"];
  $user = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM tb_user WHERE id = $id"));
  $admin = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM admin"));
  $uid = $user['id'];

  if(!isset($user['id']))
{
    //echo " unauthorized";
    header('Location: logout.php');
}

}
else{
  header("Location: login.php");
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="utf-8">
    <title>Home</title>
</head>

<body>

</body>

</html>

<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Dashboard</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
		 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
		
        
        <style type="text/css">
		body {
             font-family: arial;
             }
            .hide{
			display: none;
				}
		
		</style>
    </head>
    <?php if(isset($_POST["dark"])){
        ?><body class="sb-nav-fixed bg-dark"><?php }else { ?>
    <body class="sb-nav-fixed ">
    <?php
    
         } ?>
    <body class="sb-nav-fixed " style="background:#808080;">
        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <!-- Navbar Brand-->
            <a class="navbar-brand ps-3" href="#">Home</a>
            <!-- Sidebar Toggle-->
            <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
            <!-- Navbar Search-->
            <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
                <div class="input-group">
                    <!--<input class="form-control" type="text" placeholder="Search for..." aria-label="Search for..." aria-describedby="btnNavbarSearch" />
                    <button class="btn btn-primary" id="btnNavbarSearch" type="button"><i class="fas fa-search"></i></button>
                --></div>
            </form>
            <!-- Navbar-->
            <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="profile.php"><b><?php echo $user["firstname"];?></b></a></li>
                        
                        <li><hr class="dropdown-divider" /></li>
                        <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
        <div id="layoutSidenav">
              <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <div class="sb-sidenav-menu-heading">Profile Photo</div>
                            <a class="nav-link text-capitalize" href="profile.php">
                                <div class="sb-nav-link-icon text-light text-center">
                                    <img src="<?php echo $user['profile_img']?>" alt="profile_photo" class="img-thumbnail ml-4 col" style="border-radius: 50%; height : 120px; width : 120px;"/><!--<i class="as fa-user"></i>-->
                                <p><?php echo "<h5>".$user['firstname']."</h5>"; if($user['account_state']=='1'){ echo '<i class="fas fa-check-circle" title="verified">'; }else{ echo '<i class="fa-solid fa-ban" title="not A verified Account"></i>';} ?></i></p>
                                </div>
                        
                            </a>                            
                            <div class="collapse" id="collapsePages" aria-labelledby="headingTwo" data-bs-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav accordion" id="sidenavAccordionPages">
                                  </nav>
                            </div>
                            <div class="sb-sidenav-menu-heading">Post Related</div>
                            <a class="nav-link" href="post/home.php">
                                <div class="sb-nav-link-icon"><i class="fa-solid fa-file"></i></div>
                                View all Post
                            </a>
                            <a class="nav-link" href="addpost.php">
                                <div class="sb-nav-link-icon"><i class="fa-solid fa-file-text" aria-hidden="true"></i></div>
                                Create New
                            </a>                            
                        </div>
                    </div>
                    <div class="sb-sidenav-footer">
                        <div class="small text-capitalize">Loggedin as: <?php echo $user["firstname"];echo " ";echo $user['lastname']?></div>
                        
                    </div>
                    
                </nav>
            </div>
            <div id="layoutSidenav_content" >
                <main>
                    <div class="container-fluid px-4">
					    <div class="card m-4" >
                            <div class="card-header">
                                <i class="fas fa-table me-1"></i>
                                DataTable Example
                            </div>
                            <div class="card-body">
                                <table id="datatablesSimple">
                                    <thead>
                                        <td>
                                            <th class="text-uppercase text-center">recent post Title</th>                                                                                       
                                            <th class="text-uppercase text-center">author</th>                                            
                                            <th class="text-uppercase text-center">Last Update On</th>
                                            <th class="text-uppercase text-center">image</th>
                                            <th class="text-uppercase text-center">action</th>
                                        </td>
            </thead>
            <?php                                         
                                        global $conn;
                                        $pname = $user['firstname'];
                                        //$jsql = "SELECT pu.*,tbu.*,pu.id FROM tb_user tbu,post pu WHERE tbu.firstname = pu.author";
                                        $jsql = "SELECT * FROM  post  WHERE author = '$pname' ORDER BY post.timestamp DESC";
                                        //$jsql = "SELECT pu.*,tbu.*,pu.id FROM tb_user tbu,post pu WHERE author = '$pname'";
                                        $result = mysqli_query($conn,$jsql);
                                        while($row = mysqli_fetch_assoc($result)){

                                          $img = $row['img'];          
                                    ?>
                                    <tbody>
                                        <td class="text-center">
                                            <td class="text-capitalize text-center "><?php echo $row['title'];?></td>                                            
                                            <td class="text-capitalize text-center "><?php echo $row['author'];?></td>
                                            <!-- <td class="text-capitalize"><?php //echo $row['role'];?></td> -->
                                            <td class="text-capitalize text-center "><?php echo $row['timestamp'] ?></td>
                                            <td class="text-capitalize text-center "><?php echo '<figure class="mb-1 w-100 "><img class="img-fluid rounded w-75" style="height:120px;"  src="'.$img.'" alt="post_image" /></figure>';?></td>
                                            <td class="text-center p-5 col-sm-3">
                                                <?php
                        echo "						
                        <a class='text-primary' style='text-decoration: none' href='post/preview.php?id=". $row['id'] ."'><i class='fa-regular fa-eye fa-lg m-1' title='Preview Post'></i></a>
                        <a class='text-primary' style='text-decoration: none' id='edit_post' href='edit.php?id=". $row['id'] ."' value='edit_post' onclick='submitData();'><i class='fa fa-lg m-1 fa-pen-to-square' title='edit-this post'> </i> </a>
                        <a class='text-primary' style='text-decoration: none' id='delete_post' href='delete_post.php?id=". $row['id'] ."' value='delete_post' onclick='submitData();'><i class='fa-solid  fa-lg m-1 fa-trash-can' title='delete this post'></i> </a>";
                        

                                            ?>
                                            <!-- <button class="btn btn-outline-primary xs-4 text-capitalize">edit post</button>&nbsp; -->
                                                <!-- <button class="btn btn-outline-primary xs-4">btn</button> -->
                                        </td>
                                        </td>
                                                                            
                                        
                                        
                                    </tbody> 
                                    <?php } ?>   
                                </table>
                            </div>
                        </div>
                    </div>
                </main>
                <footer class="py-4 bg-light mt-auto bg-dark">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted text-light">Copyright &copy; Your Website 2022</div>
                            <div>
                                <a href="#" style="text-decoration: none;" class="text-light">Privacy Policy</a>
                                &middot;
                                <a href="#" style="text-decoration: none;" class="text-light">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script> -->
        <!-- <script src="assets/demo/chart-area-demo.js"></script> -->
        <!-- <script src="assets/demo/chart-bar-demo.js"></script> -->
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
    </body>
</html>
