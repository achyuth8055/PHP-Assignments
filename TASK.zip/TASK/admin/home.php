<?php
require 'function.php';
  $user = mysqli_fetch_assoc($query = mysqli_query($conn, "SELECT * FROM post ORDER BY `post`.`id` DESC"));
  if(isset($_SESSION["id"]))
{
  $id = $_SESSION["id"];
  $row = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM admin WHERE id = $id"));

}
else{
    header("Location: ../login.php");
  }
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Home.php</title>
    <!-- Favicon-->
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
    <!-- Core theme CSS (includes Bootstrap)-->
    <link href="css/styles.css" rel="stylesheet" />
</head>

<body>
    <!-- Responsive navbar-->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="#!"></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
            <div class=" container text-center">

                <h1 class="text-light text-capitalize">Welcome to Home Page <?php echo $row['username']?></h1>
            </div>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">

                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                        <!-- <li class="nav-item"><a class="nav-link" href="#!">About</a></li>
                        <li class="nav-item"><a class="nav-link" href="#!">Contact</a></li>
                        <li class="nav-item"><a class="nav-link active" aria-current="page" href="#">Blog</a></li> -->
                </ul>
            </div>
        </div>
    </nav>
    <!-- Page header with logo and tagline-->
    <header class="py-2 bg-light border-bottom mb-4">
        <div class="container">

        </div>
    </header>
    <!-- Page content-->

    <?php
              
           echo ' <div class="row m-4">
                <!-- Blog entries-->
                ';
                    
                        
                global $user;
                foreach($query as $user){
                 ?>

 
    <div class="col-md-3">
        <form class="form-group" method="post" action="">
            <div class="card mb-4 p-2">
                <div class="" name="center-block text-center">
                    <a href="#!"><img class="card-img-top img-fluid w-100" src='../user/<?php echo $user['img']?>'
                            alt="REVIEW IMAGE" style="width:16rem; height:12rem;" /></a>
                    <div class="card-body">
                        <div class="small text-muted text-capitalize">
                            <?php echo "Uploaded on ".$user['timestamp']." by ".$user['author']?></div>
                        <input type="hidden" value="<?php echo $user['id']?>" name="id">
                        <h2 class="card-title h4"><?php echo $user['title']?></h2>
                        <p class="card-text" style="
                                    overflow: hidden;
   text-overflow: ellipsis;
   display: -webkit-box;
   -webkit-line-clamp: 2; /* number of lines to show */
   -webkit-box-orient: vertical;">
                            <?php echo $user['textcontent']?>
                        </p>
                        <button class="btn" type="submit">
                            <?php echo '<a href="preview.php?id='.$user["id"].'" class="btn btn-dark"> Read more →</a>';?>
                        </button>
                    </div>

                </div>

            </div>

        </form>
    </div>


    <!-- Blog post-->

    <?php }?>


    </div>

    <!-- Footer-->
    <footer class="py-5 bg-dark">
        <div class="container">
            <p class="m-0 text-center text-white">Copyright &copy; Your Website 2022</p>
            <a href="index.php" class="m-0 text-center text-white">dashboard</a>
        </div>
    </footer>
    <!-- Bootstrap core JS-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Core theme JS-->
    <script src="js/scripts.js"></script>

</body>
<script>
function dis(e) {
    console.log('button clicked');
    event.preventDefault();

}
</script>

</html>