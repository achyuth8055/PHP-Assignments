<?php
require 'function.php';
global $id;
global $admin;
if(isset($_SESSION["id"]))
{
  $id = $_SESSION["id"];
  //$admin = $_SESSION['username'];
  $user = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM admin WHERE id = $id "));
  $query = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM post ORDER BY `post`.`id` DESC"));

 if(!isset($user['id']))
 {
    ?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>404 Error</title>
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
    </head>
    <body>
        <div id="layoutError">
            <div id="layoutError_content">
                <main>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-6">
                                <div class="text-center mt-4">
                                    <img class="mb-4 img-error" src="assets/img/error-404-monochrome.svg" />
                                    <p class="lead">You dont Have Access to the ADMIN Panel</p>
                                    <a href="logout.php">
                                        <i class="fas fa-arrow-left me-1"></i>
                                        click to Home
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
            <div id="layoutError_footer">
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; Your Website 2022</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
    </body>
</html>
    <?php
    die();
    exit;
 }
 
     
   

}

?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="utf-8">
    <title>Home</title>
</head>

<body>

</body>

</html>

<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>ADMIN PANEL </title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
		 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
		<style type="text/css">
		body {
             font-family: arial;
             }
            .hide{
			display: none;
				}
		
		</style>
    </head>
    <body class="sb-nav-fixed">
        <!-- <a href="../user/img_folder/"></a> -->
        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <!-- Navbar Brand-->
            <a class="navbar-brand ps-3" href="index.php">ADMIN PANEL</a>
            <!-- Sidebar Toggle-->
            <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
            <!-- Navbar Search-->
            <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
                <div class="input-group">
                    <!--<input class="form-control" type="text" placeholder="Search for..." aria-label="Search for..." aria-describedby="btnNavbarSearch" />
                    <button class="btn btn-primary" id="btnNavbarSearch" type="button"><i class="fas fa-search"></i></button>
                --></div>
            </form>
            <!-- Navbar-->
            <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item text-capitalize" href=""><?php  if(isset($user['username'])){ echo $user['username']; } else {echo "Admin";}?></a></li>                       
                        <li><hr class="dropdown-divider" /></li>
                        <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <div class="sb-sidenav-menu-heading">Admin</div>
                            <a class="nav-link" href="index.php">
                            <div class="sb-nav-link-icon text-light text-center">
                                    <img src="../user/img_folder/admin.png" title="admin"alt="profile_photo" class="img-thumbnail ml-4 col" style="border-radius: 50%; height : 120px; width : 120px;"/>
                                </div>
                            </a>
                           
                            <div class="sb-sidenav-menu-heading">Post Related</div>
                            <a class="nav-link" href="home.php">
                                <div class="sb-nav-link-icon"><i class="fa-solid fa-file"></i></div>
                                View all Post
                            </a>
                            <a class="nav-link" href="allusers.php">
                                <div class="sb-nav-link-icon"><i class="fa-solid fa-file-text" aria-hidden="true"></i></div>
                                View All profiles
                            </a>
                        </div>
                    </div>
                    <div class="sb-sidenav-footer">
                        <div class="small"><p class="text-capitalize">Logged in as: <?php  if(isset($user['username'])){ echo $user['username']; } else {echo "Admin";}?></p></div>
                        
                    </div>
                </nav>
            </div>
                <?php            
                        $csql = "SELECT * FROM  post ";
                        $result = mysqli_query($conn,$csql);
                        $total = 0;
                        while($row1 = mysqli_fetch_assoc($result)){$total++;}
                 ?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">					
                        <div class="card m-4">
                            <div class="card-header">
                                <i class="fas fa-table me-1"></i>
                                ADMIN TOTAL NUMBER OF POST : <?php echo $total ?>
                            </div>                      
                            <div class="card-body">
                            <table id="datatablesSimple">
                                    <thead>
                                        <tr>
                                            <th class="text-uppercase text-center">list</th>
                                            <th class="text-uppercase text-center">A-id</th>                                                                                       
                                            <th class="text-uppercase text-center">posted by</th>
                                            <th class="text-capitalize text-center">photo</th> 
                                            <th class="text-uppercase text-center">title</th>
                                          
                                            <th class="text-uppercase text-center">Edit post</th>
                                        </tr>
                                        </thead>
                                    <tbody>
                                    <?php                                         
                                        global $conn;
                                        $pname = $user['username'];                                        
                                        $jsql = "SELECT * FROM  post  ORDER BY post.timestamp DESC";                                        
                                        $result = mysqli_query($conn,$jsql);
                                        $count =1;
                                        while($row = mysqli_fetch_assoc($result)){
                                        $img = $row['img'];                                          
                                               ?>
                                        <tr>
                                            <td class="text-capitalize text-center pt-4"><?php echo $count;?></td>
                                            <td class="text-capitalize text-center pt-4"><?php echo $row['author_id'];?></td>
                                            <td class="text-capitalize text-center pt-4"><?php echo $row['author'];?></td> 
                                            <td class="text-capitalize text-center pt-4 "><?php echo '<figure class="mb-1 w-100 h-100"><img style="height:100px;"class="figure-img img-fluid rounded" src="../user/'.$img.'" alt="post_image" /></figure>';?></td>                                           
                                            <td class="text-capitalize text-center pt-4"><?php echo $row['title']; $count++; ?> </td>
                                           
                                            <td class="text-capitalize text-center pt-5">
                                                <?php
                        echo "
						<a class='text-dark' style='text-decoration: none'href='preview.php?id=". $row['id'] ."'><i class='fa-regular fa-eye fa-lg m-1'></i></a></button>
                        <a class='text-dark' style='text-decoration: none' id='edit_post' href='edit.php?id=". $row['id'] ."' value='edit_post' onclick='submitData();'><i class='fa fa-lg m-1 fa-pen-to-square '> </i> </a>
                        <a class='text-dark' style='text-decoration: none' id='delete_post' href='#id='' value='delete_post' onclick='submitData();'><i class='fa-solid  fa-lg m-1 fa-trash-can'></i> </a>";
                        
                                            ?>                                            
                                        </td>
                                        </tr>
                                        <?php }?>    
                                    </tbody>
                                </table>
                                </table>
                            </div>
                        </div>
                    </div>
                </main>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; Your Website 2022</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="assets/demo/chart-area-demo.js"></script>
        <script src="assets/demo/chart-bar-demo.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
    </body>
</html>
