<?php
require 'function.php';

if(isset($_SESSION["id"]))
{
  $id = $_SESSION["id"];
if(isset($_GET['id']))
{
 $user_id = $_GET['id'];
 $user = mysqli_fetch_assoc($res = mysqli_query($conn, "SELECT * FROM tb_user WHERE id = $user_id"));
 if(!isset($user['id']))
 {
   header("Location:error.php");
 }

}
else if(!isset($_GET['id']))
{
header("Location:error.php");
}

}
else{
  header("Location: login.php");
}
?>

<!doctype html>
<html lang="en">

<head>
    <title>Title</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<script src="script.js"></script>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>

        <style>

img {
  width: 50%;
  height: 50%;
  object-fit: cover;
  object-position: bottom;
}
        </style>
</head>

<body class="bg-primary">
    <div class="container-xl px-4 mt-4">
        <!-- Account page navigation-->
        <nav class="nav nav-borders">
            <!-- <a class="nav-link active ms-0" href="" target="__blank">Profile</a> -->
        </nav>
        <!-- <hr class="mt-0 mb-4"> -->
        <div class="row ">
            <div class="col-sm-2 mr-1">
            </div>
            <div class="col-xl-8">
                <!-- Account details card-->
                <div class="card mb-4">
                    <div class="card-header text-center h3 text-uppercase">User Deatiles</div>
                    <div class="card-body text-center">
                        <img class="img-account-profile rounded-circle w-25 img-thumbnail"
                            src="../user/<?php echo $user['profile_img']?>" alt="">
                        <div class="small font-italic text-muted" id="profile_img"></div>
                    </div>
                    <div class="card-body">
                        <form method="post" autocomplete="off">
                            <!-- Form Group (username)-->
                            <div class="mb-3">
                                <label class="small mb-1" for="inputUsername">Username</label>
                                <input class="form-control " id="username" name="username" type="text"
                                    value="<?php echo $user['username']?>" disabled>
                            </div>
                            <!-- Form Row-->
                            <div class="row gx-3 mb-3">
                                <!-- Form Group (first name)-->
                                <div class="col-md-6">
                                    <label class="small mb-1" for="firstname">First name</label>
                                    <input class="form-control text-capitalize" id="firstname" type="text"
                                        placeholder="Enter your first name" name="firstname" value="<?php echo $user['firstname']?>">
                                </div>
                                <!-- Form Group (last name)-->
                                <div class="col-md-6">
                                    <label class="small mb-1" for="lastname">Last name</label>
                                    <input class="form-control text-capitalize" id="lastname" name="lastname"type="text"
                                        placeholder="Enter your last name" value="<?php echo $user['lastname']?>">
                                </div>
                            </div>
                            <!-- Form Row        -->
                            <div class="row gx-3 mb-3">
                                <!-- Form Group (organization name)-->
                                <div class="col-md-6">
                                    <label class="small mb-1" for="role">Role</label>
                                    <input class="form-control text-capitalize" id="role"  type="text"
                                        placeholder="Enter your organization name" value="<?php echo $user['role']?>">
                                </div>
                                <!-- Form Group (location)-->
                                <div class="col-md-6">
                                    <label class="small mb-1" for="address">Location</label>
                                    <input class="form-control text-capitalize" id="address" type="text"
                                        placeholder="Enter your location" value="<?php echo $user['address']?>">
                                </div>
                            </div>
                            <div class="row gx-3 mb-3">
                                <div class="col-md-6">
                                    <label class="small mb-1" for="phone">Phone number</label>
                                    <input class="form-control" id="phone" type="tel"
                                        placeholder="Enter your phone number" maxlength="10" value="<?php echo $user['phone']?>">
                                </div>
                                <!-- Form Group (birthday)-->
                                 <!-- <div class="col-md-6 ">
                                <label class="small mb-1" for="inputBirthday">Birthday</label>
                                <input class="form-control" id="inputBirthday" type="text" name="birthday" placeholder="Enter your birthday" value="06/10/1988" disabled>
                            </div>  -->
                            </div>
                            <!-- Save changes button-->
                            <input type="hidden" id="action" value="edit_user">                           
                            <button id="edit_user" type="button" class="btn btn-primary hide hide_update" name='edit_user' onclick="submitData();">Save Changes</button>
                            <a href="user_profile.php?id=<?php echo $_GET['id'];?>"> click to check id</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous">
    </script>
</body>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
        
</html>