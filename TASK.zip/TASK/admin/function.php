<?php
session_start();
global $conn;
global $author;
global $user_id;

$conn = mysqli_connect("localhost", "root", "", "testing");

 if(isset($_SESSION["id"]))
 {
    $user_id = $_SESSION["id"];

    //header("Location:index.php");
    //echo $user_id;
  }
  $user = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM admin WHERE id ='$user_id'"));
if(isset($_POST["action"])){ 
  
   if($_POST["action"] == "login"){
    login();
  }
  if($_POST["action"] == "edit_user"){
    edit_user();
  }
    
}

function edit_user(){

  global $conn;
  if(!$conn) {
    die("Connection failed: " . mysqli_connect_error());
  }

  $firstname = $_POST['firstname']; 
  $lastname = $_POST['lastname'];
  $username = $_POST['username'];
  $address = $_POST['address'];
  $role = $_POST['role']; 
  $phone = $_POST['phone'];  
  $sql = "UPDATE tb_user SET firstname = '$firstname', lastname = '$lastname', phone = '$phone' , address = '$address', role='$role' WHERE username = '$username'";
  $query = mysqli_query($conn, $sql);
  if ($query) {
    echo "Updated User Profile As ADMIN";
    //header("Location:index.php");
  } else {
    echo "Error updating record: " . mysqli_error($conn);
  }
  
  mysqli_close($conn);
}
// LOGIN
function login(){
  global $conn;
  $username = $_POST["username"]; 
  $password = $_POST["password"];
  if($username == '' || $password=='')
  {
      echo "Please Enter Username and Password";
  }
  else if(!($username == '' || $password=='')){
  $query = "SELECT * FROM admin WHERE username = '$username'";
  $user = mysqli_query($conn,$query);
  if(mysqli_num_rows($user) > 0)
  {
    $row = mysqli_fetch_assoc($user);
    if($username == $row['username'] && $password == $row['password'])
    {
      $_SESSION["login"] = true;
      $_SESSION["id"] = $row["id"];
      $_SESSION["username"] = $row["username"];
      echo "Login Successful";
      
    } 
    else{
      echo " Wrong Password ";
      exit;
    }
    
  }
  else{
    echo " User Not Found Please Register";
    exit;
  }
}
  
}

  


?>