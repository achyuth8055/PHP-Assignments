<?php
  require 'function.php';
  global $user;
  global $tid;
  global $result;
  global $conn;
  global $username;
  global $puser;
  if(!(isset($_GET['id'])) || empty($_GET['id']))
{
    
  
    header("Location:index.php");
}
  if(isset($_SESSION['id']))
  {
      $pid  = $_GET['id'];
      $id = $_SESSION['id'];
      $user = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM admin WHERE id = $id"));
      $puser = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM post WHERE id = $pid"));
      $username = $user['username'];      
}

if(isset($_POST['submit']))
	{
	$img_name = $_FILES['img_upload']['name'];
	$tmp_img_name = $_FILES['img_upload']['tmp_name'];
	$folder = "img_folder/";
	$ext = explode('.', $img_name);
    $file_name = $ext[0];
    $file_ext = $ext[1];
    $img_url = $folder.$file_name.'_' .time().'.'.$file_ext;
    $title = $_POST['title'];
    $textcontent = mysqli_real_escape_string($conn,$_POST['textcontent']);
   // $author_name = $post['firstname'];
    //$author_id =  $post['id']; 
    //move_uploaded_file($tmp_img_name,$folder.$img_name);
    if(isset($_GET['id']))
  {
    global $id;
    $id = $_GET['id'];
	if(empty($title))
		{
    echo "<script>alert('Please FILL DEATILES')</script>";
    exit;
  }
	else { 
         $id = $_GET['id'];
         
         $sql = "SELECT * FROM post WHERE (id = '$id')";
		 $query = mysqli_query($conn,$sql);         
		 if(mysqli_fetch_array($query) > 0)
		 {		 

			$ext = explode('.', $img_name);
            $file_name = $ext[0];
            $file_ext = $ext[1];
              $img_url = $folder.$file_name.'_' .time().'.'.$file_ext;
              move_uploaded_file($tmp_img_name, "../user/".$img_url);
			  $sql = "UPDATE post SET img = '$img_url' , title = '$title' , textcontent = '$textcontent'  WHERE id = '$id'";
			  $query = mysqli_query($conn,$sql);
			  if($query)
			  {
				  echo "<script> alert('POST updated as Admin') </script>"; 

                  for($i = 5; $i > 0; $i--) {
                    echo "$i\n";
                    sleep(1);
                }
				   header("Location:index.php");
			 }
             else if(0){  
                        echo "<script> alert('POST NOT UPDATED')</script>";
                     }
         }
     }
	 } 
	
}
if(!(isset($_GET['id'])))
{ 
   header("Location:error.php");
   exit;
}
  //fetch image if exist 
  if(isset($_GET['id']))
  {
  $img_id = $_GET['id'];
  $sql = "SELECT * FROM post WHERE id = {$img_id}";
  $result = mysqli_query($conn,$sql);
  
  while ($img_row = mysqli_fetch_array($result))
  {
      global $post_name; 
      $img_url = $img_row['img'];
      $post_name = $img_row['author'];
      $title_update = $img_row['title'];
      $textcontent_update = $img_row['textcontent'];     
  }
  }
    
?>
<!doctype html>
<html lang="en">

<head>
    <title class="text-capitalize"><?php echo $user['username'] ?></title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css"
        integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">
<style type="text/css">


</style>
</head>

<body class="bg-primary">
    <!-- <img src="../" alt=""> -->
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-7">
                <div class="card shadow-lg border-0 rounded-lg mt-5">
                    <div class="card-header">
                        <h3 class="text-center font-weight-light my-2"><b class="text-uppercase">UPDATING As : <?php echo $username ?></b></h3>
                    </div>
                    <form action="" method="POST" class="form-group sm-5 m-4" enctype="multipart/form-data">
                        <div class="card" style="width: 100%;">

                            <img class="card-img-top text-capitalize" alt="INPUT_IMAGE" height='300px' width='50px' id="output"
                                src="../user/<?php echo $img_url; ?>"
                                title="<?php echo " Review by :". $post_name;?>" />
                                
                            <div class="card-body">
                                <h5 class="card-title">Select Image from Pc</h5>
                                <input type="file" name="img_upload" class="custom-file form-control-file"
                                    id="img_upload" accept="image/*" onchange="loadFile(event)" value="<?php echo $puser["img"]; ?>" required>
                            </div>
                        </div>
                        <div class="card-body">                       
                            <!-- <input type="hidden" id="post_data" name="post_data" value="post_data" class="form-control"> -->
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <div class="form-floating mb-3 mb-md-0">
                                        <input class="form-control text-capitalize" id="author_name" name="author_name"
                                            type="text" value="<?php echo $post_name; ?>" disabled />
                                        <label for="author">Author</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating">

                                        <input class="form-control text-uppercase" id="title" name="title" type="text" value="<?php echo $title_update ?>"/>
                                        <label for="title" class="form-lable text-capitalize">Post
                                            Title</label>
                                    </div>
                                </div>
                            </div>

                            <div class="form-floating mb-3">
                                <!-- <input class="form-control" id="img_url" name="img_url" type="text"required /> -->
                            </div>
                        </div>
                        <div class="row lg-3 p-1">
                                    <div class="form-floating mb-2">
                                        <div id="textcontentlable" class="hide col-xs-2" name="hide">
                                            <label for="textcontent" class="form-lable">Review Text Content</label>
                                            
                                        </div>
                                        <textarea class="form-control" placeholder="Review Content Here"
                                            style="height:100%" rows="6" cols="500" id="textcontent"  name="textcontent"
                                            type="text" maxlength="8000"> <?php echo $textcontent_update ?> </textarea>
                                    </div>
                                    <span id="message"></span>
                                </div>
                                <div class="mt-4 mb-0">
                                    <div class="d-grid mb-2">
                                        <input type="hidden" id="action" value="addpost" class='form-control'>
                                        <input type="submit" class="btn btn-md btn-primary btn-block form-group"
                                            onclick="" id='submit' value="submit" name='submit' />
                                    </div>
                                </div>
                    </form>
                    </div>

</body>
<script>
var loadFile = function(event) {
    var output = document.getElementById('output');
    output.src = URL.createObjectURL(event.target.files[0]);
    output.onload = function() {
        URL.revokeObjectURL(output.src);
    }
};
</script>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
    integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
    integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous">
</script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
    integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous">
</script>

</html>