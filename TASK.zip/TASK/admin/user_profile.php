<?php
require 'function.php';
global $user_id;
global $user;
//$user = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM tb_user"));
if($_GET['id'] == "")
{
  header("Location:error.php");
}
if(isset($_SESSION["id"]))
{
  $id = $_SESSION["id"];
  if(isset($_GET['id']))
   {
    $user_id = $_GET['id'];
    $user = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM tb_user WHERE id = $user_id"));
    if(!isset($user['id']))
    {
      header("Location:error.php");
    }

}
else if(!isset($_GET['id']) )
{
  header("Location:error.php");
}
  
}

else{
  header("Location: login.php");
}

?>
<!doctype html>
<html lang="en">
  <head>
    <title>Profile</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <style>
        .gradient-custom {
        background: #f6d365;
        background: -webkit-linear-gradient(to right bottom, rgba(246, 211, 101, 1), rgba(253, 160, 133, 1));
        background: linear-gradient(to right bottom, rgba(246, 211, 101, 1), rgba(253, 160, 133, 1))
        }
    </style>
  </head>
  <body style="background-color: #f4f5f7;">
  <div class="float-right  m-4 h-100 w-25 pt-5">

  <table class="table table-hover"  >
  <thead>
    <tr class="gradient-custom">
      <th scope="col"  class="text-center text-capitalize">P.id</th>
      <th scope="col" class="text-center text-capitalize">Firstname</th>
      <th scope="col" class="text-center text-capitalize">postname</th>
      <th scope="col" class="text-center text-capitalize">DOU</th>
    </tr>
  </thead>
  <tbody>
    <?php 

    $userid = $_GET['id'];
    $sql = "SELECT * FROM  post WHERE author_id = '$userid' ORDER BY post.timestamp";                                      
    $result = mysqli_query($conn,$sql);
    $count = 1;
    while($row = mysqli_fetch_assoc($result)){ 
      
      ?>
    <tr>
      <th scope="row"><?php echo $count;?></th>
      <td><?php echo $row['author']?></td>
      <td><?php echo $row['title']?></td>
      <td><?php echo substr($row['timestamp'], 0, 10); ?></td>
    </tr>
   <?php $count++; } ?>
  </tbody>
</table>
  </div>
  <section class="vh-100" ">  
  <div class="container  py-3 h-100 w-75">
    <div class="row d-flex  justify-center align-items-center h-100">  
    
      <div class="col col-xsm-6 mb-4 mb-lg-0">
      
      
      <?php                                         


global $conn;                                        
$jsql = "SELECT * FROM  tb_user WHERE id = '$user_id' ";                                      
$result = mysqli_query($conn,$jsql);
while($row = mysqli_fetch_assoc($result)){
$img = $row['profile_img'];
?>
        <div class="card mb-3" style="border-radius: .5rem;">
          <div class="row g-0">

            <div class="col-md-4 gradient-custom text-center text-white"
              style="border-top-left-radius: .5rem; border-bottom-left-radius: .5rem;">
              <img src="../user/<?php echo $img ?>"
                alt="Avatar" class="img-fluid my-5 rounded-circle p-1 bg-light" style="width: 100px; height:100px;" title="<?php echo " Profile Photo Of : ".$row['firstname'];?>"/>
              <h5><?php echo $row['firstname']?></h5>
              <p><?php echo $row['role']?></p>
              <i class="far fa-edit mb-5"></i>
            </div>
            <div class="col-md-8">
              <div class="card-body p-4">
                <h6 class="text-uppercase">User Information</h6>
                <hr class="mt-0 mb-4">
                <div class="row pt-1">
                  <div class="col-6 mb-3 p-2">
                    <h6>Email</h6>
                    <p class="text-muted"><?php echo $row['username']?></p>
                  </div>
                  <div class="col-6 mb-3">
                    <h6>Phone</h6>
                    <p class="text-muted"><?php echo $row['phone']?></p>
                  </div>
                </div><?php } ?><?php ?>
                
                
                <h6>Number of Post Uploaded</h6>
                <hr class="mt-0 mb-4">
                <div class="row pt-1">
                <?php
               global $conn;
                                                       
               $sql = "SELECT * FROM  post WHERE author_id = '$user_id' ";                                      
               $res = mysqli_query($conn,$sql);
               $count = 0;
               while($row_post = mysqli_fetch_assoc($res)){
               
                $count++;
                $recent_post = $row_post['title'];
               
                
              }
               ?>
                  <div class="col-6 mb-3">
                    <h6>Recent Review</h6>
                    <p class="text-muted" maxlength="25"><?php if(!isset($recent_post)){echo "No Post Uploaded";} else echo $recent_post ?></p>
                  </div>
                  <div class="col-6 mb-3">
                    <h6>Total Post Count</h6>
                    <p class="text-muted"><?php echo $count ?></p>
                  </div>
                </div>
               
                <div class="d-flex justify-content-start">
                  <a href="#!"><i class="fab fa-facebook-f fa-lg me-3"></i></a>
                  <a href="#!"><i class="fab fa-twitter fa-lg me-3"></i></a>
                  <a href="#!"><i class="fab fa-instagram fa-lg"></i></a>
                </div>
               
              </div> 
            </div>
          </div>
          <?php  ?>

        </div>
        
      </div>
    </div>
    
  </div>
</section>
   
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>