
function submitData() {
    $(document).ready(function() {
        var data = {
            action: $("#action").val(),
            firstname: $("#firstname").val(),
            lastname: $("#lastname").val(),
            username: $("#username").val(),
            password: $("#password").val(),
            confirm_password: $("#confirm_password").val(),
            role: $("#role").val(),
            phone: $("#phone").val(),
            address: $("#address").val(),
			//edit or add post
			img_url: $("#img_url").val(),
			textcontent: $("#textcontent").val(),
			author: $("#author").val(),
			title: $("#title").val(),
			
            
            // edit data
          

        };

        $.ajax({
            url: 'function.php',
            type: 'post',
            data: data,
            success: function(response) {
                console.log(response);
                console.log(data);
                swal({
                    type: "success",
                    title: "Alert Message",
                    text: response,                 
                   
                    
                }).then(function() {
                    
                    
                    location.reload();
                    
                    
                });
                // if(response == 'Login Successful')
                //  {   
                //   window.location.reload();

                // }
                // else{}
            }
        });

        //edit data


    });


    //console.log(name);
}