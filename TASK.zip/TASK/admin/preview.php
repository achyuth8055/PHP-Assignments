
<?php
require 'function.php';

if(isset($_SESSION["id"]))
{
  $id = $_SESSION["id"];
  $user = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM admin  WHERE id = $id"));
  $row = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM post  WHERE id = $id"));
  if(isset($_GET['id']))
  {
      $post_id = $_GET['id'];

  }
  if(!isset($_GET['id']))
  {
      header("Location:error.php");
      
  }
  if(!isset($row['id']))
  {
      //header("Location:error.php");
      
  }

}
else{
  header("Location: login.php");
}
?>

<?php
echo '
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Preview</title>
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <link href="css/styles.css" rel="stylesheet" />
        <script src="script.js"></script>
        <script src=""></script>
    </head>';
    echo '<body>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <div class="container">
                <a class="navbar-brand text-capitalize" href="../login.php">Welcome '.$user['username'].'</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                        <!--<li class="nav-item"><a class="nav-link" href="#">Home</a></li>
                        <li class="nav-item"><a class="nav-link" href="#!">About</a></li>
                        <li class="nav-item"><a class="nav-link" href="#!">Contact</a></li>-->
                        <li class="nav-item"><a class="btn btn-outline-light text-capitalize" aria-current="page" href="home.php">View all posts</a></li>
                        &nbsp;
                       <!-- <li class="nav-item"><a class="btn btn-outline-light text-capitalize" aria-current="page" href="#">edit Post</a></li>
                    --></ul>
                </div>
            </div>
        </nav>';
        
if(isset($_GET['id']))
{
    $pid = $_GET['id'];

global $conn;
$jsql = "SELECT * FROM post WHERE id = '$pid'";
$result = mysqli_query($conn, $jsql);
 
if($result)
 {
    if(mysqli_num_rows($result) > 0)
     {
         while($row = mysqli_fetch_assoc($result)){             
        echo'
        <form action="" method="get">
        <div class="container mt-5">   
        <div class="row">   
            <div class="col-lg-8 ">                    
                <article>
                    
                        <header class="mb-4">';
                            echo'<h1 class="fw-bolder mb-1 text-center text-uppercase">'.$row['title'].'</h1>';
                            echo'<div class="text-muted fst-italic mb-2">';
                            echo" <p class='text-capitalize'> Posted on ".$row['timestamp']." by  ".$row['author']."</p>";
                            
                        echo'</div>
                           </header>
                         
                        <figure class="mb-4"><img class="img-fluid rounded aligh-center text-center" src="../user/'. $row['img'] .'" alt="post_image" style="width:75%;height:50%;"/></figure>
                        
                        <section class="mb-5">
                            <p class="fs-5 mb-4">'.$row["textcontent"].'</p>
                            </section>
                    </article>
                    
                  
                    </form> 

                  ';     }
                  mysqli_free_result($result);
                  }
                  }
                  }
                  ?>
                    <div class="col-sm float-right  m-5 w-100 pt-5">

<table class="table table-hover"  >
<thead>
  <tr class="gradient-custom">
    <th scope="col"  class="text-center text-capitalize">P.id</th>

  </tr>
</thead>
<tbody>

  <tr>
    <th scope="row"><?php echo "data here"; ?></th></tr>

</tbody>
</table>
</div>
                </div>
   <footer class="py-5 bg-dark w-100">
            <div class="container m-0"><p class=" text-center text-white">Copyright &copy; Your Website 2022</p></div>
        </footer>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="js/scripts.js"></script>
    </body>
</html>


