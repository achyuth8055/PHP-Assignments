<?php

$city = "USA";
$weather ="";
$temp ="";
$country ="";
$windspeed ="";
$max_temp ="";
$humidity ="";

 if(isset($_GET['submit']))
{
    $city = $_GET['city'];
    $url = file_get_contents("https://api.openweathermap.org/data/2.5/weather?q=".$city."&appid=0d91b0b6845c6d0f8fd3af64629d9e5a");

    $data = json_decode($url,true);
        //print_r($data);  // to print json data in webpage 
    $weather = " Weather Condition is : " . $data['weather']['0']['description'];
    $temp = " Temperature at ". $city . " is " .$data['main']['temp'];
    $country = "Located In  : ". $data['sys']['country'];
    $windspeed = "Wind Speed is  : ". $data['wind']['speed'];
    $max_temp = "Maximum Temperature is  : ". $data['main']['temp_max'];
    $humidity = "Humidity is : ".$data['main']['humidity'];
    

  
}
//else if(isset(!($_GET['city']))){
    
  //header("Location : weather.php");
   // echo "<script>alert('failed')</script>";
//}

?>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <title>Weather</title>
  
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" />
    <link rel="stylesheet" href="css/mdb.min.css" />

    <link rel="stylesheet" href="css/style.css" />
</head>
<body>
      
  <header>
    <style>
      #intro {
        background-image: url(/img/weather.jpg);
        height: 100vh;
      }

      
    
    </style>


    <!-- Background image -->
    <div id="intro" class="bg-image shadow-2-strong">
      <div class="mask d-flex align-items-center h-100" style="background-color: rgba(0, 0, 0, 0.8);">
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-xl-5 col-md-8">
              <form class="bg-white rounded shadow-5-strong p-5" action="" method="get" autocomplete="off">
                <!-- City input -->
                <p class="h4 text-capitalize mb-4 text-center font-weight-bolder ">Live Weather Forcast</p>
                <div class="form-outline mb-4">
                  
                  <input type="text"  class="form-control" name="city"/>
                  <label class="form-label" for="form1Example1">Enter City Name</label>
                </div>
               
                <div class="row mb-4">
                  <div class="col d-flex justify-content-center">
                    <?php 
                    //echo "<div class='text-success h6'>";
                        echo "<div class='card text-white bg-success mb-3' style='max-width: 18rem;'>";
                        echo " <div class='card-header text-capitalize bg-success'>Weather Report OF :". $city ."</div>";
                        echo "<div class='card-body'>";
                        echo "<h5 class='card-title text-capitalize bg-success'>". $weather ."</h5>";
                        echo " <h6 class='card-text h6 text-capitalize'>". $temp ."</h6>";
                        echo " <h6 class='card-text h6 text-capitalize'>". $max_temp ."</h6>";
                        echo " <h6 class='card-text h6 text-capitalize'>". $humidity ."</h6>";
                        echo " <h6 class='card-text h6 text-capitalize'>". $windspeed ."</h6>";
                        echo " <h6 class='card-text h6 text-capitalize'>". $country ."</h6>";
                        echo "</div>";
                        echo " </div>"; 
                    
                   // echo "<div>";   
                     ?>
                  </div>                  
                </div>
                

                <!-- Submit button -->
                <input type="submit" class="btn btn-primary btn-block" name="submit" value="Get Deatiles">
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Background image -->
  </header>
    <script type="text/javascript" src="js/mdb.min.js"></script>
     <!--Custom scripts -->
    <script type="text/javascript" src="js/script.js"></script>
</body>
</html>